import { chmodSync, existsSync, mkdirSync, readFileSync, realpathSync, renameSync, statSync, writeFileSync } from "node:fs";
import { extname, join, resolve } from "node:path";
import { homedir, networkInterfaces } from "node:os";
import { randomBytes, randomUUID, timingSafeEqual } from "node:crypto";
import { createServer } from "node:http";
import { fileURLToPath, pathToFileURL } from "node:url";
//#region node_modules/zod/v3/helpers/util.js
var util;
(function(util) {
	util.assertEqual = (_) => {};
	function assertIs(_arg) {}
	util.assertIs = assertIs;
	function assertNever(_x) {
		throw new Error();
	}
	util.assertNever = assertNever;
	util.arrayToEnum = (items) => {
		const obj = {};
		for (const item of items) obj[item] = item;
		return obj;
	};
	util.getValidEnumValues = (obj) => {
		const validKeys = util.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
		const filtered = {};
		for (const k of validKeys) filtered[k] = obj[k];
		return util.objectValues(filtered);
	};
	util.objectValues = (obj) => {
		return util.objectKeys(obj).map(function(e) {
			return obj[e];
		});
	};
	util.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
		const keys = [];
		for (const key in object) if (Object.prototype.hasOwnProperty.call(object, key)) keys.push(key);
		return keys;
	};
	util.find = (arr, checker) => {
		for (const item of arr) if (checker(item)) return item;
	};
	util.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
	function joinValues(array, separator = " | ") {
		return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
	}
	util.joinValues = joinValues;
	util.jsonStringifyReplacer = (_, value) => {
		if (typeof value === "bigint") return value.toString();
		return value;
	};
})(util || (util = {}));
var objectUtil;
(function(objectUtil) {
	objectUtil.mergeShapes = (first, second) => {
		return {
			...first,
			...second
		};
	};
})(objectUtil || (objectUtil = {}));
var ZodParsedType = util.arrayToEnum([
	"string",
	"nan",
	"number",
	"integer",
	"float",
	"boolean",
	"date",
	"bigint",
	"symbol",
	"function",
	"undefined",
	"null",
	"array",
	"object",
	"unknown",
	"promise",
	"void",
	"never",
	"map",
	"set"
]);
var getParsedType = (data) => {
	switch (typeof data) {
		case "undefined": return ZodParsedType.undefined;
		case "string": return ZodParsedType.string;
		case "number": return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
		case "boolean": return ZodParsedType.boolean;
		case "function": return ZodParsedType.function;
		case "bigint": return ZodParsedType.bigint;
		case "symbol": return ZodParsedType.symbol;
		case "object":
			if (Array.isArray(data)) return ZodParsedType.array;
			if (data === null) return ZodParsedType.null;
			if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") return ZodParsedType.promise;
			if (typeof Map !== "undefined" && data instanceof Map) return ZodParsedType.map;
			if (typeof Set !== "undefined" && data instanceof Set) return ZodParsedType.set;
			if (typeof Date !== "undefined" && data instanceof Date) return ZodParsedType.date;
			return ZodParsedType.object;
		default: return ZodParsedType.unknown;
	}
};
//#endregion
//#region node_modules/zod/v3/ZodError.js
var ZodIssueCode = util.arrayToEnum([
	"invalid_type",
	"invalid_literal",
	"custom",
	"invalid_union",
	"invalid_union_discriminator",
	"invalid_enum_value",
	"unrecognized_keys",
	"invalid_arguments",
	"invalid_return_type",
	"invalid_date",
	"invalid_string",
	"too_small",
	"too_big",
	"invalid_intersection_types",
	"not_multiple_of",
	"not_finite"
]);
var ZodError = class ZodError extends Error {
	get errors() {
		return this.issues;
	}
	constructor(issues) {
		super();
		this.issues = [];
		this.addIssue = (sub) => {
			this.issues = [...this.issues, sub];
		};
		this.addIssues = (subs = []) => {
			this.issues = [...this.issues, ...subs];
		};
		const actualProto = new.target.prototype;
		if (Object.setPrototypeOf) Object.setPrototypeOf(this, actualProto);
		else this.__proto__ = actualProto;
		this.name = "ZodError";
		this.issues = issues;
	}
	format(_mapper) {
		const mapper = _mapper || function(issue) {
			return issue.message;
		};
		const fieldErrors = { _errors: [] };
		const processError = (error) => {
			for (const issue of error.issues) if (issue.code === "invalid_union") issue.unionErrors.map(processError);
			else if (issue.code === "invalid_return_type") processError(issue.returnTypeError);
			else if (issue.code === "invalid_arguments") processError(issue.argumentsError);
			else if (issue.path.length === 0) fieldErrors._errors.push(mapper(issue));
			else {
				let curr = fieldErrors;
				let i = 0;
				while (i < issue.path.length) {
					const el = issue.path[i];
					if (!(i === issue.path.length - 1)) curr[el] = curr[el] || { _errors: [] };
					else {
						curr[el] = curr[el] || { _errors: [] };
						curr[el]._errors.push(mapper(issue));
					}
					curr = curr[el];
					i++;
				}
			}
		};
		processError(this);
		return fieldErrors;
	}
	static assert(value) {
		if (!(value instanceof ZodError)) throw new Error(`Not a ZodError: ${value}`);
	}
	toString() {
		return this.message;
	}
	get message() {
		return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
	}
	get isEmpty() {
		return this.issues.length === 0;
	}
	flatten(mapper = (issue) => issue.message) {
		const fieldErrors = {};
		const formErrors = [];
		for (const sub of this.issues) if (sub.path.length > 0) {
			const firstEl = sub.path[0];
			fieldErrors[firstEl] = fieldErrors[firstEl] || [];
			fieldErrors[firstEl].push(mapper(sub));
		} else formErrors.push(mapper(sub));
		return {
			formErrors,
			fieldErrors
		};
	}
	get formErrors() {
		return this.flatten();
	}
};
ZodError.create = (issues) => {
	return new ZodError(issues);
};
//#endregion
//#region node_modules/zod/v3/locales/en.js
var errorMap = (issue, _ctx) => {
	let message;
	switch (issue.code) {
		case ZodIssueCode.invalid_type:
			if (issue.received === ZodParsedType.undefined) message = "Required";
			else message = `Expected ${issue.expected}, received ${issue.received}`;
			break;
		case ZodIssueCode.invalid_literal:
			message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
			break;
		case ZodIssueCode.unrecognized_keys:
			message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
			break;
		case ZodIssueCode.invalid_union:
			message = `Invalid input`;
			break;
		case ZodIssueCode.invalid_union_discriminator:
			message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
			break;
		case ZodIssueCode.invalid_enum_value:
			message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
			break;
		case ZodIssueCode.invalid_arguments:
			message = `Invalid function arguments`;
			break;
		case ZodIssueCode.invalid_return_type:
			message = `Invalid function return type`;
			break;
		case ZodIssueCode.invalid_date:
			message = `Invalid date`;
			break;
		case ZodIssueCode.invalid_string:
			if (typeof issue.validation === "object") if ("includes" in issue.validation) {
				message = `Invalid input: must include "${issue.validation.includes}"`;
				if (typeof issue.validation.position === "number") message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
			} else if ("startsWith" in issue.validation) message = `Invalid input: must start with "${issue.validation.startsWith}"`;
			else if ("endsWith" in issue.validation) message = `Invalid input: must end with "${issue.validation.endsWith}"`;
			else util.assertNever(issue.validation);
			else if (issue.validation !== "regex") message = `Invalid ${issue.validation}`;
			else message = "Invalid";
			break;
		case ZodIssueCode.too_small:
			if (issue.type === "array") message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
			else if (issue.type === "string") message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
			else if (issue.type === "number") message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
			else if (issue.type === "bigint") message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
			else if (issue.type === "date") message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
			else message = "Invalid input";
			break;
		case ZodIssueCode.too_big:
			if (issue.type === "array") message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
			else if (issue.type === "string") message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
			else if (issue.type === "number") message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
			else if (issue.type === "bigint") message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
			else if (issue.type === "date") message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
			else message = "Invalid input";
			break;
		case ZodIssueCode.custom:
			message = `Invalid input`;
			break;
		case ZodIssueCode.invalid_intersection_types:
			message = `Intersection results could not be merged`;
			break;
		case ZodIssueCode.not_multiple_of:
			message = `Number must be a multiple of ${issue.multipleOf}`;
			break;
		case ZodIssueCode.not_finite:
			message = "Number must be finite";
			break;
		default:
			message = _ctx.defaultError;
			util.assertNever(issue);
	}
	return { message };
};
//#endregion
//#region node_modules/zod/v3/errors.js
var overrideErrorMap = errorMap;
function getErrorMap() {
	return overrideErrorMap;
}
//#endregion
//#region node_modules/zod/v3/helpers/parseUtil.js
var makeIssue = (params) => {
	const { data, path, errorMaps, issueData } = params;
	const fullPath = [...path, ...issueData.path || []];
	const fullIssue = {
		...issueData,
		path: fullPath
	};
	if (issueData.message !== void 0) return {
		...issueData,
		path: fullPath,
		message: issueData.message
	};
	let errorMessage = "";
	const maps = errorMaps.filter((m) => !!m).slice().reverse();
	for (const map of maps) errorMessage = map(fullIssue, {
		data,
		defaultError: errorMessage
	}).message;
	return {
		...issueData,
		path: fullPath,
		message: errorMessage
	};
};
function addIssueToContext(ctx, issueData) {
	const overrideMap = getErrorMap();
	const issue = makeIssue({
		issueData,
		data: ctx.data,
		path: ctx.path,
		errorMaps: [
			ctx.common.contextualErrorMap,
			ctx.schemaErrorMap,
			overrideMap,
			overrideMap === errorMap ? void 0 : errorMap
		].filter((x) => !!x)
	});
	ctx.common.issues.push(issue);
}
var ParseStatus = class ParseStatus {
	constructor() {
		this.value = "valid";
	}
	dirty() {
		if (this.value === "valid") this.value = "dirty";
	}
	abort() {
		if (this.value !== "aborted") this.value = "aborted";
	}
	static mergeArray(status, results) {
		const arrayValue = [];
		for (const s of results) {
			if (s.status === "aborted") return INVALID;
			if (s.status === "dirty") status.dirty();
			arrayValue.push(s.value);
		}
		return {
			status: status.value,
			value: arrayValue
		};
	}
	static async mergeObjectAsync(status, pairs) {
		const syncPairs = [];
		for (const pair of pairs) {
			const key = await pair.key;
			const value = await pair.value;
			syncPairs.push({
				key,
				value
			});
		}
		return ParseStatus.mergeObjectSync(status, syncPairs);
	}
	static mergeObjectSync(status, pairs) {
		const finalObject = {};
		for (const pair of pairs) {
			const { key, value } = pair;
			if (key.status === "aborted") return INVALID;
			if (value.status === "aborted") return INVALID;
			if (key.status === "dirty") status.dirty();
			if (value.status === "dirty") status.dirty();
			if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) finalObject[key.value] = value.value;
		}
		return {
			status: status.value,
			value: finalObject
		};
	}
};
var INVALID = Object.freeze({ status: "aborted" });
var DIRTY = (value) => ({
	status: "dirty",
	value
});
var OK = (value) => ({
	status: "valid",
	value
});
var isAborted = (x) => x.status === "aborted";
var isDirty = (x) => x.status === "dirty";
var isValid = (x) => x.status === "valid";
var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;
//#endregion
//#region node_modules/zod/v3/helpers/errorUtil.js
var errorUtil;
(function(errorUtil) {
	errorUtil.errToObj = (message) => typeof message === "string" ? { message } : message || {};
	errorUtil.toString = (message) => typeof message === "string" ? message : message?.message;
})(errorUtil || (errorUtil = {}));
//#endregion
//#region node_modules/zod/v3/types.js
var ParseInputLazyPath = class {
	constructor(parent, value, path, key) {
		this._cachedPath = [];
		this.parent = parent;
		this.data = value;
		this._path = path;
		this._key = key;
	}
	get path() {
		if (!this._cachedPath.length) if (Array.isArray(this._key)) this._cachedPath.push(...this._path, ...this._key);
		else this._cachedPath.push(...this._path, this._key);
		return this._cachedPath;
	}
};
var handleResult = (ctx, result) => {
	if (isValid(result)) return {
		success: true,
		data: result.value
	};
	else {
		if (!ctx.common.issues.length) throw new Error("Validation failed but no issues detected.");
		return {
			success: false,
			get error() {
				if (this._error) return this._error;
				const error = new ZodError(ctx.common.issues);
				this._error = error;
				return this._error;
			}
		};
	}
};
function processCreateParams(params) {
	if (!params) return {};
	const { errorMap, invalid_type_error, required_error, description } = params;
	if (errorMap && (invalid_type_error || required_error)) throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
	if (errorMap) return {
		errorMap,
		description
	};
	const customMap = (iss, ctx) => {
		const { message } = params;
		if (iss.code === "invalid_enum_value") return { message: message ?? ctx.defaultError };
		if (typeof ctx.data === "undefined") return { message: message ?? required_error ?? ctx.defaultError };
		if (iss.code !== "invalid_type") return { message: ctx.defaultError };
		return { message: message ?? invalid_type_error ?? ctx.defaultError };
	};
	return {
		errorMap: customMap,
		description
	};
}
var ZodType = class {
	get description() {
		return this._def.description;
	}
	_getType(input) {
		return getParsedType(input.data);
	}
	_getOrReturnCtx(input, ctx) {
		return ctx || {
			common: input.parent.common,
			data: input.data,
			parsedType: getParsedType(input.data),
			schemaErrorMap: this._def.errorMap,
			path: input.path,
			parent: input.parent
		};
	}
	_processInputParams(input) {
		return {
			status: new ParseStatus(),
			ctx: {
				common: input.parent.common,
				data: input.data,
				parsedType: getParsedType(input.data),
				schemaErrorMap: this._def.errorMap,
				path: input.path,
				parent: input.parent
			}
		};
	}
	_parseSync(input) {
		const result = this._parse(input);
		if (isAsync(result)) throw new Error("Synchronous parse encountered promise.");
		return result;
	}
	_parseAsync(input) {
		const result = this._parse(input);
		return Promise.resolve(result);
	}
	parse(data, params) {
		const result = this.safeParse(data, params);
		if (result.success) return result.data;
		throw result.error;
	}
	safeParse(data, params) {
		const ctx = {
			common: {
				issues: [],
				async: params?.async ?? false,
				contextualErrorMap: params?.errorMap
			},
			path: params?.path || [],
			schemaErrorMap: this._def.errorMap,
			parent: null,
			data,
			parsedType: getParsedType(data)
		};
		return handleResult(ctx, this._parseSync({
			data,
			path: ctx.path,
			parent: ctx
		}));
	}
	"~validate"(data) {
		const ctx = {
			common: {
				issues: [],
				async: !!this["~standard"].async
			},
			path: [],
			schemaErrorMap: this._def.errorMap,
			parent: null,
			data,
			parsedType: getParsedType(data)
		};
		if (!this["~standard"].async) try {
			const result = this._parseSync({
				data,
				path: [],
				parent: ctx
			});
			return isValid(result) ? { value: result.value } : { issues: ctx.common.issues };
		} catch (err) {
			if (err?.message?.toLowerCase()?.includes("encountered")) this["~standard"].async = true;
			ctx.common = {
				issues: [],
				async: true
			};
		}
		return this._parseAsync({
			data,
			path: [],
			parent: ctx
		}).then((result) => isValid(result) ? { value: result.value } : { issues: ctx.common.issues });
	}
	async parseAsync(data, params) {
		const result = await this.safeParseAsync(data, params);
		if (result.success) return result.data;
		throw result.error;
	}
	async safeParseAsync(data, params) {
		const ctx = {
			common: {
				issues: [],
				contextualErrorMap: params?.errorMap,
				async: true
			},
			path: params?.path || [],
			schemaErrorMap: this._def.errorMap,
			parent: null,
			data,
			parsedType: getParsedType(data)
		};
		const maybeAsyncResult = this._parse({
			data,
			path: ctx.path,
			parent: ctx
		});
		return handleResult(ctx, await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult)));
	}
	refine(check, message) {
		const getIssueProperties = (val) => {
			if (typeof message === "string" || typeof message === "undefined") return { message };
			else if (typeof message === "function") return message(val);
			else return message;
		};
		return this._refinement((val, ctx) => {
			const result = check(val);
			const setError = () => ctx.addIssue({
				code: ZodIssueCode.custom,
				...getIssueProperties(val)
			});
			if (typeof Promise !== "undefined" && result instanceof Promise) return result.then((data) => {
				if (!data) {
					setError();
					return false;
				} else return true;
			});
			if (!result) {
				setError();
				return false;
			} else return true;
		});
	}
	refinement(check, refinementData) {
		return this._refinement((val, ctx) => {
			if (!check(val)) {
				ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
				return false;
			} else return true;
		});
	}
	_refinement(refinement) {
		return new ZodEffects({
			schema: this,
			typeName: ZodFirstPartyTypeKind.ZodEffects,
			effect: {
				type: "refinement",
				refinement
			}
		});
	}
	superRefine(refinement) {
		return this._refinement(refinement);
	}
	constructor(def) {
		/** Alias of safeParseAsync */
		this.spa = this.safeParseAsync;
		this._def = def;
		this.parse = this.parse.bind(this);
		this.safeParse = this.safeParse.bind(this);
		this.parseAsync = this.parseAsync.bind(this);
		this.safeParseAsync = this.safeParseAsync.bind(this);
		this.spa = this.spa.bind(this);
		this.refine = this.refine.bind(this);
		this.refinement = this.refinement.bind(this);
		this.superRefine = this.superRefine.bind(this);
		this.optional = this.optional.bind(this);
		this.nullable = this.nullable.bind(this);
		this.nullish = this.nullish.bind(this);
		this.array = this.array.bind(this);
		this.promise = this.promise.bind(this);
		this.or = this.or.bind(this);
		this.and = this.and.bind(this);
		this.transform = this.transform.bind(this);
		this.brand = this.brand.bind(this);
		this.default = this.default.bind(this);
		this.catch = this.catch.bind(this);
		this.describe = this.describe.bind(this);
		this.pipe = this.pipe.bind(this);
		this.readonly = this.readonly.bind(this);
		this.isNullable = this.isNullable.bind(this);
		this.isOptional = this.isOptional.bind(this);
		this["~standard"] = {
			version: 1,
			vendor: "zod",
			validate: (data) => this["~validate"](data)
		};
	}
	optional() {
		return ZodOptional.create(this, this._def);
	}
	nullable() {
		return ZodNullable.create(this, this._def);
	}
	nullish() {
		return this.nullable().optional();
	}
	array() {
		return ZodArray.create(this);
	}
	promise() {
		return ZodPromise.create(this, this._def);
	}
	or(option) {
		return ZodUnion.create([this, option], this._def);
	}
	and(incoming) {
		return ZodIntersection.create(this, incoming, this._def);
	}
	transform(transform) {
		return new ZodEffects({
			...processCreateParams(this._def),
			schema: this,
			typeName: ZodFirstPartyTypeKind.ZodEffects,
			effect: {
				type: "transform",
				transform
			}
		});
	}
	default(def) {
		const defaultValueFunc = typeof def === "function" ? def : () => def;
		return new ZodDefault({
			...processCreateParams(this._def),
			innerType: this,
			defaultValue: defaultValueFunc,
			typeName: ZodFirstPartyTypeKind.ZodDefault
		});
	}
	brand() {
		return new ZodBranded({
			typeName: ZodFirstPartyTypeKind.ZodBranded,
			type: this,
			...processCreateParams(this._def)
		});
	}
	catch(def) {
		const catchValueFunc = typeof def === "function" ? def : () => def;
		return new ZodCatch({
			...processCreateParams(this._def),
			innerType: this,
			catchValue: catchValueFunc,
			typeName: ZodFirstPartyTypeKind.ZodCatch
		});
	}
	describe(description) {
		const This = this.constructor;
		return new This({
			...this._def,
			description
		});
	}
	pipe(target) {
		return ZodPipeline.create(this, target);
	}
	readonly() {
		return ZodReadonly.create(this);
	}
	isOptional() {
		return this.safeParse(void 0).success;
	}
	isNullable() {
		return this.safeParse(null).success;
	}
};
var cuidRegex = /^c[^\s-]{8,}$/i;
var cuid2Regex = /^[0-9a-z]+$/;
var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
var nanoidRegex = /^[a-z0-9_-]{21}$/i;
var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
var emojiRegex;
var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
var dateRegex = new RegExp(`^${dateRegexSource}$`);
function timeRegexSource(args) {
	let secondsRegexSource = `[0-5]\\d`;
	if (args.precision) secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
	else if (args.precision == null) secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
	const secondsQuantifier = args.precision ? "+" : "?";
	return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
}
function timeRegex(args) {
	return new RegExp(`^${timeRegexSource(args)}$`);
}
function datetimeRegex(args) {
	let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
	const opts = [];
	opts.push(args.local ? `Z?` : `Z`);
	if (args.offset) opts.push(`([+-]\\d{2}:?\\d{2})`);
	regex = `${regex}(${opts.join("|")})`;
	return new RegExp(`^${regex}$`);
}
function isValidIP(ip, version) {
	if ((version === "v4" || !version) && ipv4Regex.test(ip)) return true;
	if ((version === "v6" || !version) && ipv6Regex.test(ip)) return true;
	return false;
}
function isValidJWT(jwt, alg) {
	if (!jwtRegex.test(jwt)) return false;
	try {
		const [header] = jwt.split(".");
		if (!header) return false;
		const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
		const decoded = JSON.parse(atob(base64));
		if (typeof decoded !== "object" || decoded === null) return false;
		if ("typ" in decoded && decoded?.typ !== "JWT") return false;
		if (!decoded.alg) return false;
		if (alg && decoded.alg !== alg) return false;
		return true;
	} catch {
		return false;
	}
}
function isValidCidr(ip, version) {
	if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) return true;
	if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) return true;
	return false;
}
var ZodString = class ZodString extends ZodType {
	_parse(input) {
		if (this._def.coerce) input.data = String(input.data);
		if (this._getType(input) !== ZodParsedType.string) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.string,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const status = new ParseStatus();
		let ctx = void 0;
		for (const check of this._def.checks) if (check.kind === "min") {
			if (input.data.length < check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					minimum: check.value,
					type: "string",
					inclusive: true,
					exact: false,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "max") {
			if (input.data.length > check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					maximum: check.value,
					type: "string",
					inclusive: true,
					exact: false,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "length") {
			const tooBig = input.data.length > check.value;
			const tooSmall = input.data.length < check.value;
			if (tooBig || tooSmall) {
				ctx = this._getOrReturnCtx(input, ctx);
				if (tooBig) addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					maximum: check.value,
					type: "string",
					inclusive: true,
					exact: true,
					message: check.message
				});
				else if (tooSmall) addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					minimum: check.value,
					type: "string",
					inclusive: true,
					exact: true,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "email") {
			if (!emailRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "email",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "emoji") {
			if (!emojiRegex) emojiRegex = new RegExp(_emojiRegex, "u");
			if (!emojiRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "emoji",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "uuid") {
			if (!uuidRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "uuid",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "nanoid") {
			if (!nanoidRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "nanoid",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "cuid") {
			if (!cuidRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "cuid",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "cuid2") {
			if (!cuid2Regex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "cuid2",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "ulid") {
			if (!ulidRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "ulid",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "url") try {
			new URL(input.data);
		} catch {
			ctx = this._getOrReturnCtx(input, ctx);
			addIssueToContext(ctx, {
				validation: "url",
				code: ZodIssueCode.invalid_string,
				message: check.message
			});
			status.dirty();
		}
		else if (check.kind === "regex") {
			check.regex.lastIndex = 0;
			if (!check.regex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "regex",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "trim") input.data = input.data.trim();
		else if (check.kind === "includes") {
			if (!input.data.includes(check.value, check.position)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: {
						includes: check.value,
						position: check.position
					},
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "toLowerCase") input.data = input.data.toLowerCase();
		else if (check.kind === "toUpperCase") input.data = input.data.toUpperCase();
		else if (check.kind === "startsWith") {
			if (!input.data.startsWith(check.value)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: { startsWith: check.value },
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "endsWith") {
			if (!input.data.endsWith(check.value)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: { endsWith: check.value },
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "datetime") {
			if (!datetimeRegex(check).test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: "datetime",
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "date") {
			if (!dateRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: "date",
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "time") {
			if (!timeRegex(check).test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_string,
					validation: "time",
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "duration") {
			if (!durationRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "duration",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "ip") {
			if (!isValidIP(input.data, check.version)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "ip",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "jwt") {
			if (!isValidJWT(input.data, check.alg)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "jwt",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "cidr") {
			if (!isValidCidr(input.data, check.version)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "cidr",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "base64") {
			if (!base64Regex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "base64",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "base64url") {
			if (!base64urlRegex.test(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					validation: "base64url",
					code: ZodIssueCode.invalid_string,
					message: check.message
				});
				status.dirty();
			}
		} else util.assertNever(check);
		return {
			status: status.value,
			value: input.data
		};
	}
	_regex(regex, validation, message) {
		return this.refinement((data) => regex.test(data), {
			validation,
			code: ZodIssueCode.invalid_string,
			...errorUtil.errToObj(message)
		});
	}
	_addCheck(check) {
		return new ZodString({
			...this._def,
			checks: [...this._def.checks, check]
		});
	}
	email(message) {
		return this._addCheck({
			kind: "email",
			...errorUtil.errToObj(message)
		});
	}
	url(message) {
		return this._addCheck({
			kind: "url",
			...errorUtil.errToObj(message)
		});
	}
	emoji(message) {
		return this._addCheck({
			kind: "emoji",
			...errorUtil.errToObj(message)
		});
	}
	uuid(message) {
		return this._addCheck({
			kind: "uuid",
			...errorUtil.errToObj(message)
		});
	}
	nanoid(message) {
		return this._addCheck({
			kind: "nanoid",
			...errorUtil.errToObj(message)
		});
	}
	cuid(message) {
		return this._addCheck({
			kind: "cuid",
			...errorUtil.errToObj(message)
		});
	}
	cuid2(message) {
		return this._addCheck({
			kind: "cuid2",
			...errorUtil.errToObj(message)
		});
	}
	ulid(message) {
		return this._addCheck({
			kind: "ulid",
			...errorUtil.errToObj(message)
		});
	}
	base64(message) {
		return this._addCheck({
			kind: "base64",
			...errorUtil.errToObj(message)
		});
	}
	base64url(message) {
		return this._addCheck({
			kind: "base64url",
			...errorUtil.errToObj(message)
		});
	}
	jwt(options) {
		return this._addCheck({
			kind: "jwt",
			...errorUtil.errToObj(options)
		});
	}
	ip(options) {
		return this._addCheck({
			kind: "ip",
			...errorUtil.errToObj(options)
		});
	}
	cidr(options) {
		return this._addCheck({
			kind: "cidr",
			...errorUtil.errToObj(options)
		});
	}
	datetime(options) {
		if (typeof options === "string") return this._addCheck({
			kind: "datetime",
			precision: null,
			offset: false,
			local: false,
			message: options
		});
		return this._addCheck({
			kind: "datetime",
			precision: typeof options?.precision === "undefined" ? null : options?.precision,
			offset: options?.offset ?? false,
			local: options?.local ?? false,
			...errorUtil.errToObj(options?.message)
		});
	}
	date(message) {
		return this._addCheck({
			kind: "date",
			message
		});
	}
	time(options) {
		if (typeof options === "string") return this._addCheck({
			kind: "time",
			precision: null,
			message: options
		});
		return this._addCheck({
			kind: "time",
			precision: typeof options?.precision === "undefined" ? null : options?.precision,
			...errorUtil.errToObj(options?.message)
		});
	}
	duration(message) {
		return this._addCheck({
			kind: "duration",
			...errorUtil.errToObj(message)
		});
	}
	regex(regex, message) {
		return this._addCheck({
			kind: "regex",
			regex,
			...errorUtil.errToObj(message)
		});
	}
	includes(value, options) {
		return this._addCheck({
			kind: "includes",
			value,
			position: options?.position,
			...errorUtil.errToObj(options?.message)
		});
	}
	startsWith(value, message) {
		return this._addCheck({
			kind: "startsWith",
			value,
			...errorUtil.errToObj(message)
		});
	}
	endsWith(value, message) {
		return this._addCheck({
			kind: "endsWith",
			value,
			...errorUtil.errToObj(message)
		});
	}
	min(minLength, message) {
		return this._addCheck({
			kind: "min",
			value: minLength,
			...errorUtil.errToObj(message)
		});
	}
	max(maxLength, message) {
		return this._addCheck({
			kind: "max",
			value: maxLength,
			...errorUtil.errToObj(message)
		});
	}
	length(len, message) {
		return this._addCheck({
			kind: "length",
			value: len,
			...errorUtil.errToObj(message)
		});
	}
	/**
	* Equivalent to `.min(1)`
	*/
	nonempty(message) {
		return this.min(1, errorUtil.errToObj(message));
	}
	trim() {
		return new ZodString({
			...this._def,
			checks: [...this._def.checks, { kind: "trim" }]
		});
	}
	toLowerCase() {
		return new ZodString({
			...this._def,
			checks: [...this._def.checks, { kind: "toLowerCase" }]
		});
	}
	toUpperCase() {
		return new ZodString({
			...this._def,
			checks: [...this._def.checks, { kind: "toUpperCase" }]
		});
	}
	get isDatetime() {
		return !!this._def.checks.find((ch) => ch.kind === "datetime");
	}
	get isDate() {
		return !!this._def.checks.find((ch) => ch.kind === "date");
	}
	get isTime() {
		return !!this._def.checks.find((ch) => ch.kind === "time");
	}
	get isDuration() {
		return !!this._def.checks.find((ch) => ch.kind === "duration");
	}
	get isEmail() {
		return !!this._def.checks.find((ch) => ch.kind === "email");
	}
	get isURL() {
		return !!this._def.checks.find((ch) => ch.kind === "url");
	}
	get isEmoji() {
		return !!this._def.checks.find((ch) => ch.kind === "emoji");
	}
	get isUUID() {
		return !!this._def.checks.find((ch) => ch.kind === "uuid");
	}
	get isNANOID() {
		return !!this._def.checks.find((ch) => ch.kind === "nanoid");
	}
	get isCUID() {
		return !!this._def.checks.find((ch) => ch.kind === "cuid");
	}
	get isCUID2() {
		return !!this._def.checks.find((ch) => ch.kind === "cuid2");
	}
	get isULID() {
		return !!this._def.checks.find((ch) => ch.kind === "ulid");
	}
	get isIP() {
		return !!this._def.checks.find((ch) => ch.kind === "ip");
	}
	get isCIDR() {
		return !!this._def.checks.find((ch) => ch.kind === "cidr");
	}
	get isBase64() {
		return !!this._def.checks.find((ch) => ch.kind === "base64");
	}
	get isBase64url() {
		return !!this._def.checks.find((ch) => ch.kind === "base64url");
	}
	get minLength() {
		let min = null;
		for (const ch of this._def.checks) if (ch.kind === "min") {
			if (min === null || ch.value > min) min = ch.value;
		}
		return min;
	}
	get maxLength() {
		let max = null;
		for (const ch of this._def.checks) if (ch.kind === "max") {
			if (max === null || ch.value < max) max = ch.value;
		}
		return max;
	}
};
ZodString.create = (params) => {
	return new ZodString({
		checks: [],
		typeName: ZodFirstPartyTypeKind.ZodString,
		coerce: params?.coerce ?? false,
		...processCreateParams(params)
	});
};
function floatSafeRemainder(val, step) {
	const valDecCount = (val.toString().split(".")[1] || "").length;
	const stepDecCount = (step.toString().split(".")[1] || "").length;
	const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
	return Number.parseInt(val.toFixed(decCount).replace(".", "")) % Number.parseInt(step.toFixed(decCount).replace(".", "")) / 10 ** decCount;
}
var ZodNumber = class ZodNumber extends ZodType {
	constructor() {
		super(...arguments);
		this.min = this.gte;
		this.max = this.lte;
		this.step = this.multipleOf;
	}
	_parse(input) {
		if (this._def.coerce) input.data = Number(input.data);
		if (this._getType(input) !== ZodParsedType.number) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.number,
				received: ctx.parsedType
			});
			return INVALID;
		}
		let ctx = void 0;
		const status = new ParseStatus();
		for (const check of this._def.checks) if (check.kind === "int") {
			if (!util.isInteger(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.invalid_type,
					expected: "integer",
					received: "float",
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "min") {
			if (check.inclusive ? input.data < check.value : input.data <= check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					minimum: check.value,
					type: "number",
					inclusive: check.inclusive,
					exact: false,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "max") {
			if (check.inclusive ? input.data > check.value : input.data >= check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					maximum: check.value,
					type: "number",
					inclusive: check.inclusive,
					exact: false,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "multipleOf") {
			if (floatSafeRemainder(input.data, check.value) !== 0) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.not_multiple_of,
					multipleOf: check.value,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "finite") {
			if (!Number.isFinite(input.data)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.not_finite,
					message: check.message
				});
				status.dirty();
			}
		} else util.assertNever(check);
		return {
			status: status.value,
			value: input.data
		};
	}
	gte(value, message) {
		return this.setLimit("min", value, true, errorUtil.toString(message));
	}
	gt(value, message) {
		return this.setLimit("min", value, false, errorUtil.toString(message));
	}
	lte(value, message) {
		return this.setLimit("max", value, true, errorUtil.toString(message));
	}
	lt(value, message) {
		return this.setLimit("max", value, false, errorUtil.toString(message));
	}
	setLimit(kind, value, inclusive, message) {
		return new ZodNumber({
			...this._def,
			checks: [...this._def.checks, {
				kind,
				value,
				inclusive,
				message: errorUtil.toString(message)
			}]
		});
	}
	_addCheck(check) {
		return new ZodNumber({
			...this._def,
			checks: [...this._def.checks, check]
		});
	}
	int(message) {
		return this._addCheck({
			kind: "int",
			message: errorUtil.toString(message)
		});
	}
	positive(message) {
		return this._addCheck({
			kind: "min",
			value: 0,
			inclusive: false,
			message: errorUtil.toString(message)
		});
	}
	negative(message) {
		return this._addCheck({
			kind: "max",
			value: 0,
			inclusive: false,
			message: errorUtil.toString(message)
		});
	}
	nonpositive(message) {
		return this._addCheck({
			kind: "max",
			value: 0,
			inclusive: true,
			message: errorUtil.toString(message)
		});
	}
	nonnegative(message) {
		return this._addCheck({
			kind: "min",
			value: 0,
			inclusive: true,
			message: errorUtil.toString(message)
		});
	}
	multipleOf(value, message) {
		return this._addCheck({
			kind: "multipleOf",
			value,
			message: errorUtil.toString(message)
		});
	}
	finite(message) {
		return this._addCheck({
			kind: "finite",
			message: errorUtil.toString(message)
		});
	}
	safe(message) {
		return this._addCheck({
			kind: "min",
			inclusive: true,
			value: Number.MIN_SAFE_INTEGER,
			message: errorUtil.toString(message)
		})._addCheck({
			kind: "max",
			inclusive: true,
			value: Number.MAX_SAFE_INTEGER,
			message: errorUtil.toString(message)
		});
	}
	get minValue() {
		let min = null;
		for (const ch of this._def.checks) if (ch.kind === "min") {
			if (min === null || ch.value > min) min = ch.value;
		}
		return min;
	}
	get maxValue() {
		let max = null;
		for (const ch of this._def.checks) if (ch.kind === "max") {
			if (max === null || ch.value < max) max = ch.value;
		}
		return max;
	}
	get isInt() {
		return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
	}
	get isFinite() {
		let max = null;
		let min = null;
		for (const ch of this._def.checks) if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") return true;
		else if (ch.kind === "min") {
			if (min === null || ch.value > min) min = ch.value;
		} else if (ch.kind === "max") {
			if (max === null || ch.value < max) max = ch.value;
		}
		return Number.isFinite(min) && Number.isFinite(max);
	}
};
ZodNumber.create = (params) => {
	return new ZodNumber({
		checks: [],
		typeName: ZodFirstPartyTypeKind.ZodNumber,
		coerce: params?.coerce || false,
		...processCreateParams(params)
	});
};
var ZodBigInt = class ZodBigInt extends ZodType {
	constructor() {
		super(...arguments);
		this.min = this.gte;
		this.max = this.lte;
	}
	_parse(input) {
		if (this._def.coerce) try {
			input.data = BigInt(input.data);
		} catch {
			return this._getInvalidInput(input);
		}
		if (this._getType(input) !== ZodParsedType.bigint) return this._getInvalidInput(input);
		let ctx = void 0;
		const status = new ParseStatus();
		for (const check of this._def.checks) if (check.kind === "min") {
			if (check.inclusive ? input.data < check.value : input.data <= check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					type: "bigint",
					minimum: check.value,
					inclusive: check.inclusive,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "max") {
			if (check.inclusive ? input.data > check.value : input.data >= check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					type: "bigint",
					maximum: check.value,
					inclusive: check.inclusive,
					message: check.message
				});
				status.dirty();
			}
		} else if (check.kind === "multipleOf") {
			if (input.data % check.value !== BigInt(0)) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.not_multiple_of,
					multipleOf: check.value,
					message: check.message
				});
				status.dirty();
			}
		} else util.assertNever(check);
		return {
			status: status.value,
			value: input.data
		};
	}
	_getInvalidInput(input) {
		const ctx = this._getOrReturnCtx(input);
		addIssueToContext(ctx, {
			code: ZodIssueCode.invalid_type,
			expected: ZodParsedType.bigint,
			received: ctx.parsedType
		});
		return INVALID;
	}
	gte(value, message) {
		return this.setLimit("min", value, true, errorUtil.toString(message));
	}
	gt(value, message) {
		return this.setLimit("min", value, false, errorUtil.toString(message));
	}
	lte(value, message) {
		return this.setLimit("max", value, true, errorUtil.toString(message));
	}
	lt(value, message) {
		return this.setLimit("max", value, false, errorUtil.toString(message));
	}
	setLimit(kind, value, inclusive, message) {
		return new ZodBigInt({
			...this._def,
			checks: [...this._def.checks, {
				kind,
				value,
				inclusive,
				message: errorUtil.toString(message)
			}]
		});
	}
	_addCheck(check) {
		return new ZodBigInt({
			...this._def,
			checks: [...this._def.checks, check]
		});
	}
	positive(message) {
		return this._addCheck({
			kind: "min",
			value: BigInt(0),
			inclusive: false,
			message: errorUtil.toString(message)
		});
	}
	negative(message) {
		return this._addCheck({
			kind: "max",
			value: BigInt(0),
			inclusive: false,
			message: errorUtil.toString(message)
		});
	}
	nonpositive(message) {
		return this._addCheck({
			kind: "max",
			value: BigInt(0),
			inclusive: true,
			message: errorUtil.toString(message)
		});
	}
	nonnegative(message) {
		return this._addCheck({
			kind: "min",
			value: BigInt(0),
			inclusive: true,
			message: errorUtil.toString(message)
		});
	}
	multipleOf(value, message) {
		return this._addCheck({
			kind: "multipleOf",
			value,
			message: errorUtil.toString(message)
		});
	}
	get minValue() {
		let min = null;
		for (const ch of this._def.checks) if (ch.kind === "min") {
			if (min === null || ch.value > min) min = ch.value;
		}
		return min;
	}
	get maxValue() {
		let max = null;
		for (const ch of this._def.checks) if (ch.kind === "max") {
			if (max === null || ch.value < max) max = ch.value;
		}
		return max;
	}
};
ZodBigInt.create = (params) => {
	return new ZodBigInt({
		checks: [],
		typeName: ZodFirstPartyTypeKind.ZodBigInt,
		coerce: params?.coerce ?? false,
		...processCreateParams(params)
	});
};
var ZodBoolean = class extends ZodType {
	_parse(input) {
		if (this._def.coerce) input.data = Boolean(input.data);
		if (this._getType(input) !== ZodParsedType.boolean) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.boolean,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK(input.data);
	}
};
ZodBoolean.create = (params) => {
	return new ZodBoolean({
		typeName: ZodFirstPartyTypeKind.ZodBoolean,
		coerce: params?.coerce || false,
		...processCreateParams(params)
	});
};
var ZodDate = class ZodDate extends ZodType {
	_parse(input) {
		if (this._def.coerce) input.data = new Date(input.data);
		if (this._getType(input) !== ZodParsedType.date) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.date,
				received: ctx.parsedType
			});
			return INVALID;
		}
		if (Number.isNaN(input.data.getTime())) {
			addIssueToContext(this._getOrReturnCtx(input), { code: ZodIssueCode.invalid_date });
			return INVALID;
		}
		const status = new ParseStatus();
		let ctx = void 0;
		for (const check of this._def.checks) if (check.kind === "min") {
			if (input.data.getTime() < check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					message: check.message,
					inclusive: true,
					exact: false,
					minimum: check.value,
					type: "date"
				});
				status.dirty();
			}
		} else if (check.kind === "max") {
			if (input.data.getTime() > check.value) {
				ctx = this._getOrReturnCtx(input, ctx);
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					message: check.message,
					inclusive: true,
					exact: false,
					maximum: check.value,
					type: "date"
				});
				status.dirty();
			}
		} else util.assertNever(check);
		return {
			status: status.value,
			value: new Date(input.data.getTime())
		};
	}
	_addCheck(check) {
		return new ZodDate({
			...this._def,
			checks: [...this._def.checks, check]
		});
	}
	min(minDate, message) {
		return this._addCheck({
			kind: "min",
			value: minDate.getTime(),
			message: errorUtil.toString(message)
		});
	}
	max(maxDate, message) {
		return this._addCheck({
			kind: "max",
			value: maxDate.getTime(),
			message: errorUtil.toString(message)
		});
	}
	get minDate() {
		let min = null;
		for (const ch of this._def.checks) if (ch.kind === "min") {
			if (min === null || ch.value > min) min = ch.value;
		}
		return min != null ? new Date(min) : null;
	}
	get maxDate() {
		let max = null;
		for (const ch of this._def.checks) if (ch.kind === "max") {
			if (max === null || ch.value < max) max = ch.value;
		}
		return max != null ? new Date(max) : null;
	}
};
ZodDate.create = (params) => {
	return new ZodDate({
		checks: [],
		coerce: params?.coerce || false,
		typeName: ZodFirstPartyTypeKind.ZodDate,
		...processCreateParams(params)
	});
};
var ZodSymbol = class extends ZodType {
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.symbol) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.symbol,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK(input.data);
	}
};
ZodSymbol.create = (params) => {
	return new ZodSymbol({
		typeName: ZodFirstPartyTypeKind.ZodSymbol,
		...processCreateParams(params)
	});
};
var ZodUndefined = class extends ZodType {
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.undefined) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.undefined,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK(input.data);
	}
};
ZodUndefined.create = (params) => {
	return new ZodUndefined({
		typeName: ZodFirstPartyTypeKind.ZodUndefined,
		...processCreateParams(params)
	});
};
var ZodNull = class extends ZodType {
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.null) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.null,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK(input.data);
	}
};
ZodNull.create = (params) => {
	return new ZodNull({
		typeName: ZodFirstPartyTypeKind.ZodNull,
		...processCreateParams(params)
	});
};
var ZodAny = class extends ZodType {
	constructor() {
		super(...arguments);
		this._any = true;
	}
	_parse(input) {
		return OK(input.data);
	}
};
ZodAny.create = (params) => {
	return new ZodAny({
		typeName: ZodFirstPartyTypeKind.ZodAny,
		...processCreateParams(params)
	});
};
var ZodUnknown = class extends ZodType {
	constructor() {
		super(...arguments);
		this._unknown = true;
	}
	_parse(input) {
		return OK(input.data);
	}
};
ZodUnknown.create = (params) => {
	return new ZodUnknown({
		typeName: ZodFirstPartyTypeKind.ZodUnknown,
		...processCreateParams(params)
	});
};
var ZodNever = class extends ZodType {
	_parse(input) {
		const ctx = this._getOrReturnCtx(input);
		addIssueToContext(ctx, {
			code: ZodIssueCode.invalid_type,
			expected: ZodParsedType.never,
			received: ctx.parsedType
		});
		return INVALID;
	}
};
ZodNever.create = (params) => {
	return new ZodNever({
		typeName: ZodFirstPartyTypeKind.ZodNever,
		...processCreateParams(params)
	});
};
var ZodVoid = class extends ZodType {
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.undefined) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.void,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK(input.data);
	}
};
ZodVoid.create = (params) => {
	return new ZodVoid({
		typeName: ZodFirstPartyTypeKind.ZodVoid,
		...processCreateParams(params)
	});
};
var ZodArray = class ZodArray extends ZodType {
	_parse(input) {
		const { ctx, status } = this._processInputParams(input);
		const def = this._def;
		if (ctx.parsedType !== ZodParsedType.array) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.array,
				received: ctx.parsedType
			});
			return INVALID;
		}
		if (def.exactLength !== null) {
			const tooBig = ctx.data.length > def.exactLength.value;
			const tooSmall = ctx.data.length < def.exactLength.value;
			if (tooBig || tooSmall) {
				addIssueToContext(ctx, {
					code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
					minimum: tooSmall ? def.exactLength.value : void 0,
					maximum: tooBig ? def.exactLength.value : void 0,
					type: "array",
					inclusive: true,
					exact: true,
					message: def.exactLength.message
				});
				status.dirty();
			}
		}
		if (def.minLength !== null) {
			if (ctx.data.length < def.minLength.value) {
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					minimum: def.minLength.value,
					type: "array",
					inclusive: true,
					exact: false,
					message: def.minLength.message
				});
				status.dirty();
			}
		}
		if (def.maxLength !== null) {
			if (ctx.data.length > def.maxLength.value) {
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					maximum: def.maxLength.value,
					type: "array",
					inclusive: true,
					exact: false,
					message: def.maxLength.message
				});
				status.dirty();
			}
		}
		if (ctx.common.async) return Promise.all([...ctx.data].map((item, i) => {
			return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
		})).then((result) => {
			return ParseStatus.mergeArray(status, result);
		});
		const result = [...ctx.data].map((item, i) => {
			return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
		});
		return ParseStatus.mergeArray(status, result);
	}
	get element() {
		return this._def.type;
	}
	min(minLength, message) {
		return new ZodArray({
			...this._def,
			minLength: {
				value: minLength,
				message: errorUtil.toString(message)
			}
		});
	}
	max(maxLength, message) {
		return new ZodArray({
			...this._def,
			maxLength: {
				value: maxLength,
				message: errorUtil.toString(message)
			}
		});
	}
	length(len, message) {
		return new ZodArray({
			...this._def,
			exactLength: {
				value: len,
				message: errorUtil.toString(message)
			}
		});
	}
	nonempty(message) {
		return this.min(1, message);
	}
};
ZodArray.create = (schema, params) => {
	return new ZodArray({
		type: schema,
		minLength: null,
		maxLength: null,
		exactLength: null,
		typeName: ZodFirstPartyTypeKind.ZodArray,
		...processCreateParams(params)
	});
};
function deepPartialify(schema) {
	if (schema instanceof ZodObject) {
		const newShape = {};
		for (const key in schema.shape) {
			const fieldSchema = schema.shape[key];
			newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
		}
		return new ZodObject({
			...schema._def,
			shape: () => newShape
		});
	} else if (schema instanceof ZodArray) return new ZodArray({
		...schema._def,
		type: deepPartialify(schema.element)
	});
	else if (schema instanceof ZodOptional) return ZodOptional.create(deepPartialify(schema.unwrap()));
	else if (schema instanceof ZodNullable) return ZodNullable.create(deepPartialify(schema.unwrap()));
	else if (schema instanceof ZodTuple) return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
	else return schema;
}
var ZodObject = class ZodObject extends ZodType {
	constructor() {
		super(...arguments);
		this._cached = null;
		/**
		* @deprecated In most cases, this is no longer needed - unknown properties are now silently stripped.
		* If you want to pass through unknown properties, use `.passthrough()` instead.
		*/
		this.nonstrict = this.passthrough;
		/**
		* @deprecated Use `.extend` instead
		*  */
		this.augment = this.extend;
	}
	_getCached() {
		if (this._cached !== null) return this._cached;
		const shape = this._def.shape();
		const keys = util.objectKeys(shape);
		this._cached = {
			shape,
			keys
		};
		return this._cached;
	}
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.object) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.object,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const { status, ctx } = this._processInputParams(input);
		const { shape, keys: shapeKeys } = this._getCached();
		const extraKeys = [];
		if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
			for (const key in ctx.data) if (!shapeKeys.includes(key)) extraKeys.push(key);
		}
		const pairs = [];
		for (const key of shapeKeys) {
			const keyValidator = shape[key];
			const value = ctx.data[key];
			pairs.push({
				key: {
					status: "valid",
					value: key
				},
				value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
				alwaysSet: key in ctx.data
			});
		}
		if (this._def.catchall instanceof ZodNever) {
			const unknownKeys = this._def.unknownKeys;
			if (unknownKeys === "passthrough") for (const key of extraKeys) pairs.push({
				key: {
					status: "valid",
					value: key
				},
				value: {
					status: "valid",
					value: ctx.data[key]
				}
			});
			else if (unknownKeys === "strict") {
				if (extraKeys.length > 0) {
					addIssueToContext(ctx, {
						code: ZodIssueCode.unrecognized_keys,
						keys: extraKeys
					});
					status.dirty();
				}
			} else if (unknownKeys === "strip") {} else throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
		} else {
			const catchall = this._def.catchall;
			for (const key of extraKeys) {
				const value = ctx.data[key];
				pairs.push({
					key: {
						status: "valid",
						value: key
					},
					value: catchall._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
					alwaysSet: key in ctx.data
				});
			}
		}
		if (ctx.common.async) return Promise.resolve().then(async () => {
			const syncPairs = [];
			for (const pair of pairs) {
				const key = await pair.key;
				const value = await pair.value;
				syncPairs.push({
					key,
					value,
					alwaysSet: pair.alwaysSet
				});
			}
			return syncPairs;
		}).then((syncPairs) => {
			return ParseStatus.mergeObjectSync(status, syncPairs);
		});
		else return ParseStatus.mergeObjectSync(status, pairs);
	}
	get shape() {
		return this._def.shape();
	}
	strict(message) {
		errorUtil.errToObj;
		return new ZodObject({
			...this._def,
			unknownKeys: "strict",
			...message !== void 0 ? { errorMap: (issue, ctx) => {
				const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
				if (issue.code === "unrecognized_keys") return { message: errorUtil.errToObj(message).message ?? defaultError };
				return { message: defaultError };
			} } : {}
		});
	}
	strip() {
		return new ZodObject({
			...this._def,
			unknownKeys: "strip"
		});
	}
	passthrough() {
		return new ZodObject({
			...this._def,
			unknownKeys: "passthrough"
		});
	}
	extend(augmentation) {
		return new ZodObject({
			...this._def,
			shape: () => ({
				...this._def.shape(),
				...augmentation
			})
		});
	}
	/**
	* Prior to zod@1.0.12 there was a bug in the
	* inferred type of merged objects. Please
	* upgrade if you are experiencing issues.
	*/
	merge(merging) {
		return new ZodObject({
			unknownKeys: merging._def.unknownKeys,
			catchall: merging._def.catchall,
			shape: () => ({
				...this._def.shape(),
				...merging._def.shape()
			}),
			typeName: ZodFirstPartyTypeKind.ZodObject
		});
	}
	setKey(key, schema) {
		return this.augment({ [key]: schema });
	}
	catchall(index) {
		return new ZodObject({
			...this._def,
			catchall: index
		});
	}
	pick(mask) {
		const shape = {};
		for (const key of util.objectKeys(mask)) if (mask[key] && this.shape[key]) shape[key] = this.shape[key];
		return new ZodObject({
			...this._def,
			shape: () => shape
		});
	}
	omit(mask) {
		const shape = {};
		for (const key of util.objectKeys(this.shape)) if (!mask[key]) shape[key] = this.shape[key];
		return new ZodObject({
			...this._def,
			shape: () => shape
		});
	}
	/**
	* @deprecated
	*/
	deepPartial() {
		return deepPartialify(this);
	}
	partial(mask) {
		const newShape = {};
		for (const key of util.objectKeys(this.shape)) {
			const fieldSchema = this.shape[key];
			if (mask && !mask[key]) newShape[key] = fieldSchema;
			else newShape[key] = fieldSchema.optional();
		}
		return new ZodObject({
			...this._def,
			shape: () => newShape
		});
	}
	required(mask) {
		const newShape = {};
		for (const key of util.objectKeys(this.shape)) if (mask && !mask[key]) newShape[key] = this.shape[key];
		else {
			let newField = this.shape[key];
			while (newField instanceof ZodOptional) newField = newField._def.innerType;
			newShape[key] = newField;
		}
		return new ZodObject({
			...this._def,
			shape: () => newShape
		});
	}
	keyof() {
		return createZodEnum(util.objectKeys(this.shape));
	}
};
ZodObject.create = (shape, params) => {
	return new ZodObject({
		shape: () => shape,
		unknownKeys: "strip",
		catchall: ZodNever.create(),
		typeName: ZodFirstPartyTypeKind.ZodObject,
		...processCreateParams(params)
	});
};
ZodObject.strictCreate = (shape, params) => {
	return new ZodObject({
		shape: () => shape,
		unknownKeys: "strict",
		catchall: ZodNever.create(),
		typeName: ZodFirstPartyTypeKind.ZodObject,
		...processCreateParams(params)
	});
};
ZodObject.lazycreate = (shape, params) => {
	return new ZodObject({
		shape,
		unknownKeys: "strip",
		catchall: ZodNever.create(),
		typeName: ZodFirstPartyTypeKind.ZodObject,
		...processCreateParams(params)
	});
};
var ZodUnion = class extends ZodType {
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		const options = this._def.options;
		function handleResults(results) {
			for (const result of results) if (result.result.status === "valid") return result.result;
			for (const result of results) if (result.result.status === "dirty") {
				ctx.common.issues.push(...result.ctx.common.issues);
				return result.result;
			}
			const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_union,
				unionErrors
			});
			return INVALID;
		}
		if (ctx.common.async) return Promise.all(options.map(async (option) => {
			const childCtx = {
				...ctx,
				common: {
					...ctx.common,
					issues: []
				},
				parent: null
			};
			return {
				result: await option._parseAsync({
					data: ctx.data,
					path: ctx.path,
					parent: childCtx
				}),
				ctx: childCtx
			};
		})).then(handleResults);
		else {
			let dirty = void 0;
			const issues = [];
			for (const option of options) {
				const childCtx = {
					...ctx,
					common: {
						...ctx.common,
						issues: []
					},
					parent: null
				};
				const result = option._parseSync({
					data: ctx.data,
					path: ctx.path,
					parent: childCtx
				});
				if (result.status === "valid") return result;
				else if (result.status === "dirty" && !dirty) dirty = {
					result,
					ctx: childCtx
				};
				if (childCtx.common.issues.length) issues.push(childCtx.common.issues);
			}
			if (dirty) {
				ctx.common.issues.push(...dirty.ctx.common.issues);
				return dirty.result;
			}
			const unionErrors = issues.map((issues) => new ZodError(issues));
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_union,
				unionErrors
			});
			return INVALID;
		}
	}
	get options() {
		return this._def.options;
	}
};
ZodUnion.create = (types, params) => {
	return new ZodUnion({
		options: types,
		typeName: ZodFirstPartyTypeKind.ZodUnion,
		...processCreateParams(params)
	});
};
var getDiscriminator = (type) => {
	if (type instanceof ZodLazy) return getDiscriminator(type.schema);
	else if (type instanceof ZodEffects) return getDiscriminator(type.innerType());
	else if (type instanceof ZodLiteral) return [type.value];
	else if (type instanceof ZodEnum) return type.options;
	else if (type instanceof ZodNativeEnum) return util.objectValues(type.enum);
	else if (type instanceof ZodDefault) return getDiscriminator(type._def.innerType);
	else if (type instanceof ZodUndefined) return [void 0];
	else if (type instanceof ZodNull) return [null];
	else if (type instanceof ZodOptional) return [void 0, ...getDiscriminator(type.unwrap())];
	else if (type instanceof ZodNullable) return [null, ...getDiscriminator(type.unwrap())];
	else if (type instanceof ZodBranded) return getDiscriminator(type.unwrap());
	else if (type instanceof ZodReadonly) return getDiscriminator(type.unwrap());
	else if (type instanceof ZodCatch) return getDiscriminator(type._def.innerType);
	else return [];
};
var ZodDiscriminatedUnion = class ZodDiscriminatedUnion extends ZodType {
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.object) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.object,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const discriminator = this.discriminator;
		const discriminatorValue = ctx.data[discriminator];
		const option = this.optionsMap.get(discriminatorValue);
		if (!option) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_union_discriminator,
				options: Array.from(this.optionsMap.keys()),
				path: [discriminator]
			});
			return INVALID;
		}
		if (ctx.common.async) return option._parseAsync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		});
		else return option._parseSync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		});
	}
	get discriminator() {
		return this._def.discriminator;
	}
	get options() {
		return this._def.options;
	}
	get optionsMap() {
		return this._def.optionsMap;
	}
	/**
	* The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
	* However, it only allows a union of objects, all of which need to share a discriminator property. This property must
	* have a different value for each object in the union.
	* @param discriminator the name of the discriminator property
	* @param types an array of object schemas
	* @param params
	*/
	static create(discriminator, options, params) {
		const optionsMap = /* @__PURE__ */ new Map();
		for (const type of options) {
			const discriminatorValues = getDiscriminator(type.shape[discriminator]);
			if (!discriminatorValues.length) throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
			for (const value of discriminatorValues) {
				if (optionsMap.has(value)) throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
				optionsMap.set(value, type);
			}
		}
		return new ZodDiscriminatedUnion({
			typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
			discriminator,
			options,
			optionsMap,
			...processCreateParams(params)
		});
	}
};
function mergeValues(a, b) {
	const aType = getParsedType(a);
	const bType = getParsedType(b);
	if (a === b) return {
		valid: true,
		data: a
	};
	else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
		const bKeys = util.objectKeys(b);
		const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
		const newObj = {
			...a,
			...b
		};
		for (const key of sharedKeys) {
			const sharedValue = mergeValues(a[key], b[key]);
			if (!sharedValue.valid) return { valid: false };
			newObj[key] = sharedValue.data;
		}
		return {
			valid: true,
			data: newObj
		};
	} else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
		if (a.length !== b.length) return { valid: false };
		const newArray = [];
		for (let index = 0; index < a.length; index++) {
			const itemA = a[index];
			const itemB = b[index];
			const sharedValue = mergeValues(itemA, itemB);
			if (!sharedValue.valid) return { valid: false };
			newArray.push(sharedValue.data);
		}
		return {
			valid: true,
			data: newArray
		};
	} else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) return {
		valid: true,
		data: a
	};
	else return { valid: false };
}
var ZodIntersection = class extends ZodType {
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		const handleParsed = (parsedLeft, parsedRight) => {
			if (isAborted(parsedLeft) || isAborted(parsedRight)) return INVALID;
			const merged = mergeValues(parsedLeft.value, parsedRight.value);
			if (!merged.valid) {
				addIssueToContext(ctx, { code: ZodIssueCode.invalid_intersection_types });
				return INVALID;
			}
			if (isDirty(parsedLeft) || isDirty(parsedRight)) status.dirty();
			return {
				status: status.value,
				value: merged.data
			};
		};
		if (ctx.common.async) return Promise.all([this._def.left._parseAsync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		}), this._def.right._parseAsync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		})]).then(([left, right]) => handleParsed(left, right));
		else return handleParsed(this._def.left._parseSync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		}), this._def.right._parseSync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		}));
	}
};
ZodIntersection.create = (left, right, params) => {
	return new ZodIntersection({
		left,
		right,
		typeName: ZodFirstPartyTypeKind.ZodIntersection,
		...processCreateParams(params)
	});
};
var ZodTuple = class ZodTuple extends ZodType {
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.array) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.array,
				received: ctx.parsedType
			});
			return INVALID;
		}
		if (ctx.data.length < this._def.items.length) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.too_small,
				minimum: this._def.items.length,
				inclusive: true,
				exact: false,
				type: "array"
			});
			return INVALID;
		}
		if (!this._def.rest && ctx.data.length > this._def.items.length) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.too_big,
				maximum: this._def.items.length,
				inclusive: true,
				exact: false,
				type: "array"
			});
			status.dirty();
		}
		const items = [...ctx.data].map((item, itemIndex) => {
			const schema = this._def.items[itemIndex] || this._def.rest;
			if (!schema) return null;
			return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
		}).filter((x) => !!x);
		if (ctx.common.async) return Promise.all(items).then((results) => {
			return ParseStatus.mergeArray(status, results);
		});
		else return ParseStatus.mergeArray(status, items);
	}
	get items() {
		return this._def.items;
	}
	rest(rest) {
		return new ZodTuple({
			...this._def,
			rest
		});
	}
};
ZodTuple.create = (schemas, params) => {
	if (!Array.isArray(schemas)) throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
	return new ZodTuple({
		items: schemas,
		typeName: ZodFirstPartyTypeKind.ZodTuple,
		rest: null,
		...processCreateParams(params)
	});
};
var ZodRecord = class ZodRecord extends ZodType {
	get keySchema() {
		return this._def.keyType;
	}
	get valueSchema() {
		return this._def.valueType;
	}
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.object) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.object,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const pairs = [];
		const keyType = this._def.keyType;
		const valueType = this._def.valueType;
		for (const key in ctx.data) pairs.push({
			key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
			value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
			alwaysSet: key in ctx.data
		});
		if (ctx.common.async) return ParseStatus.mergeObjectAsync(status, pairs);
		else return ParseStatus.mergeObjectSync(status, pairs);
	}
	get element() {
		return this._def.valueType;
	}
	static create(first, second, third) {
		if (second instanceof ZodType) return new ZodRecord({
			keyType: first,
			valueType: second,
			typeName: ZodFirstPartyTypeKind.ZodRecord,
			...processCreateParams(third)
		});
		return new ZodRecord({
			keyType: ZodString.create(),
			valueType: first,
			typeName: ZodFirstPartyTypeKind.ZodRecord,
			...processCreateParams(second)
		});
	}
};
var ZodMap = class extends ZodType {
	get keySchema() {
		return this._def.keyType;
	}
	get valueSchema() {
		return this._def.valueType;
	}
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.map) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.map,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const keyType = this._def.keyType;
		const valueType = this._def.valueType;
		const pairs = [...ctx.data.entries()].map(([key, value], index) => {
			return {
				key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
				value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
			};
		});
		if (ctx.common.async) {
			const finalMap = /* @__PURE__ */ new Map();
			return Promise.resolve().then(async () => {
				for (const pair of pairs) {
					const key = await pair.key;
					const value = await pair.value;
					if (key.status === "aborted" || value.status === "aborted") return INVALID;
					if (key.status === "dirty" || value.status === "dirty") status.dirty();
					finalMap.set(key.value, value.value);
				}
				return {
					status: status.value,
					value: finalMap
				};
			});
		} else {
			const finalMap = /* @__PURE__ */ new Map();
			for (const pair of pairs) {
				const key = pair.key;
				const value = pair.value;
				if (key.status === "aborted" || value.status === "aborted") return INVALID;
				if (key.status === "dirty" || value.status === "dirty") status.dirty();
				finalMap.set(key.value, value.value);
			}
			return {
				status: status.value,
				value: finalMap
			};
		}
	}
};
ZodMap.create = (keyType, valueType, params) => {
	return new ZodMap({
		valueType,
		keyType,
		typeName: ZodFirstPartyTypeKind.ZodMap,
		...processCreateParams(params)
	});
};
var ZodSet = class ZodSet extends ZodType {
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.set) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.set,
				received: ctx.parsedType
			});
			return INVALID;
		}
		const def = this._def;
		if (def.minSize !== null) {
			if (ctx.data.size < def.minSize.value) {
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_small,
					minimum: def.minSize.value,
					type: "set",
					inclusive: true,
					exact: false,
					message: def.minSize.message
				});
				status.dirty();
			}
		}
		if (def.maxSize !== null) {
			if (ctx.data.size > def.maxSize.value) {
				addIssueToContext(ctx, {
					code: ZodIssueCode.too_big,
					maximum: def.maxSize.value,
					type: "set",
					inclusive: true,
					exact: false,
					message: def.maxSize.message
				});
				status.dirty();
			}
		}
		const valueType = this._def.valueType;
		function finalizeSet(elements) {
			const parsedSet = /* @__PURE__ */ new Set();
			for (const element of elements) {
				if (element.status === "aborted") return INVALID;
				if (element.status === "dirty") status.dirty();
				parsedSet.add(element.value);
			}
			return {
				status: status.value,
				value: parsedSet
			};
		}
		const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
		if (ctx.common.async) return Promise.all(elements).then((elements) => finalizeSet(elements));
		else return finalizeSet(elements);
	}
	min(minSize, message) {
		return new ZodSet({
			...this._def,
			minSize: {
				value: minSize,
				message: errorUtil.toString(message)
			}
		});
	}
	max(maxSize, message) {
		return new ZodSet({
			...this._def,
			maxSize: {
				value: maxSize,
				message: errorUtil.toString(message)
			}
		});
	}
	size(size, message) {
		return this.min(size, message).max(size, message);
	}
	nonempty(message) {
		return this.min(1, message);
	}
};
ZodSet.create = (valueType, params) => {
	return new ZodSet({
		valueType,
		minSize: null,
		maxSize: null,
		typeName: ZodFirstPartyTypeKind.ZodSet,
		...processCreateParams(params)
	});
};
var ZodFunction = class ZodFunction extends ZodType {
	constructor() {
		super(...arguments);
		this.validate = this.implement;
	}
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.function) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.function,
				received: ctx.parsedType
			});
			return INVALID;
		}
		function makeArgsIssue(args, error) {
			return makeIssue({
				data: args,
				path: ctx.path,
				errorMaps: [
					ctx.common.contextualErrorMap,
					ctx.schemaErrorMap,
					getErrorMap(),
					errorMap
				].filter((x) => !!x),
				issueData: {
					code: ZodIssueCode.invalid_arguments,
					argumentsError: error
				}
			});
		}
		function makeReturnsIssue(returns, error) {
			return makeIssue({
				data: returns,
				path: ctx.path,
				errorMaps: [
					ctx.common.contextualErrorMap,
					ctx.schemaErrorMap,
					getErrorMap(),
					errorMap
				].filter((x) => !!x),
				issueData: {
					code: ZodIssueCode.invalid_return_type,
					returnTypeError: error
				}
			});
		}
		const params = { errorMap: ctx.common.contextualErrorMap };
		const fn = ctx.data;
		if (this._def.returns instanceof ZodPromise) {
			const me = this;
			return OK(async function(...args) {
				const error = new ZodError([]);
				const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
					error.addIssue(makeArgsIssue(args, e));
					throw error;
				});
				const result = await Reflect.apply(fn, this, parsedArgs);
				return await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
					error.addIssue(makeReturnsIssue(result, e));
					throw error;
				});
			});
		} else {
			const me = this;
			return OK(function(...args) {
				const parsedArgs = me._def.args.safeParse(args, params);
				if (!parsedArgs.success) throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
				const result = Reflect.apply(fn, this, parsedArgs.data);
				const parsedReturns = me._def.returns.safeParse(result, params);
				if (!parsedReturns.success) throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
				return parsedReturns.data;
			});
		}
	}
	parameters() {
		return this._def.args;
	}
	returnType() {
		return this._def.returns;
	}
	args(...items) {
		return new ZodFunction({
			...this._def,
			args: ZodTuple.create(items).rest(ZodUnknown.create())
		});
	}
	returns(returnType) {
		return new ZodFunction({
			...this._def,
			returns: returnType
		});
	}
	implement(func) {
		return this.parse(func);
	}
	strictImplement(func) {
		return this.parse(func);
	}
	static create(args, returns, params) {
		return new ZodFunction({
			args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
			returns: returns || ZodUnknown.create(),
			typeName: ZodFirstPartyTypeKind.ZodFunction,
			...processCreateParams(params)
		});
	}
};
var ZodLazy = class extends ZodType {
	get schema() {
		return this._def.getter();
	}
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		return this._def.getter()._parse({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		});
	}
};
ZodLazy.create = (getter, params) => {
	return new ZodLazy({
		getter,
		typeName: ZodFirstPartyTypeKind.ZodLazy,
		...processCreateParams(params)
	});
};
var ZodLiteral = class extends ZodType {
	_parse(input) {
		if (input.data !== this._def.value) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				received: ctx.data,
				code: ZodIssueCode.invalid_literal,
				expected: this._def.value
			});
			return INVALID;
		}
		return {
			status: "valid",
			value: input.data
		};
	}
	get value() {
		return this._def.value;
	}
};
ZodLiteral.create = (value, params) => {
	return new ZodLiteral({
		value,
		typeName: ZodFirstPartyTypeKind.ZodLiteral,
		...processCreateParams(params)
	});
};
function createZodEnum(values, params) {
	return new ZodEnum({
		values,
		typeName: ZodFirstPartyTypeKind.ZodEnum,
		...processCreateParams(params)
	});
}
var ZodEnum = class ZodEnum extends ZodType {
	_parse(input) {
		if (typeof input.data !== "string") {
			const ctx = this._getOrReturnCtx(input);
			const expectedValues = this._def.values;
			addIssueToContext(ctx, {
				expected: util.joinValues(expectedValues),
				received: ctx.parsedType,
				code: ZodIssueCode.invalid_type
			});
			return INVALID;
		}
		if (!this._cache) this._cache = new Set(this._def.values);
		if (!this._cache.has(input.data)) {
			const ctx = this._getOrReturnCtx(input);
			const expectedValues = this._def.values;
			addIssueToContext(ctx, {
				received: ctx.data,
				code: ZodIssueCode.invalid_enum_value,
				options: expectedValues
			});
			return INVALID;
		}
		return OK(input.data);
	}
	get options() {
		return this._def.values;
	}
	get enum() {
		const enumValues = {};
		for (const val of this._def.values) enumValues[val] = val;
		return enumValues;
	}
	get Values() {
		const enumValues = {};
		for (const val of this._def.values) enumValues[val] = val;
		return enumValues;
	}
	get Enum() {
		const enumValues = {};
		for (const val of this._def.values) enumValues[val] = val;
		return enumValues;
	}
	extract(values, newDef = this._def) {
		return ZodEnum.create(values, {
			...this._def,
			...newDef
		});
	}
	exclude(values, newDef = this._def) {
		return ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
			...this._def,
			...newDef
		});
	}
};
ZodEnum.create = createZodEnum;
var ZodNativeEnum = class extends ZodType {
	_parse(input) {
		const nativeEnumValues = util.getValidEnumValues(this._def.values);
		const ctx = this._getOrReturnCtx(input);
		if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
			const expectedValues = util.objectValues(nativeEnumValues);
			addIssueToContext(ctx, {
				expected: util.joinValues(expectedValues),
				received: ctx.parsedType,
				code: ZodIssueCode.invalid_type
			});
			return INVALID;
		}
		if (!this._cache) this._cache = new Set(util.getValidEnumValues(this._def.values));
		if (!this._cache.has(input.data)) {
			const expectedValues = util.objectValues(nativeEnumValues);
			addIssueToContext(ctx, {
				received: ctx.data,
				code: ZodIssueCode.invalid_enum_value,
				options: expectedValues
			});
			return INVALID;
		}
		return OK(input.data);
	}
	get enum() {
		return this._def.values;
	}
};
ZodNativeEnum.create = (values, params) => {
	return new ZodNativeEnum({
		values,
		typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
		...processCreateParams(params)
	});
};
var ZodPromise = class extends ZodType {
	unwrap() {
		return this._def.type;
	}
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.promise,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return OK((ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data)).then((data) => {
			return this._def.type.parseAsync(data, {
				path: ctx.path,
				errorMap: ctx.common.contextualErrorMap
			});
		}));
	}
};
ZodPromise.create = (schema, params) => {
	return new ZodPromise({
		type: schema,
		typeName: ZodFirstPartyTypeKind.ZodPromise,
		...processCreateParams(params)
	});
};
var ZodEffects = class extends ZodType {
	innerType() {
		return this._def.schema;
	}
	sourceType() {
		return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
	}
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		const effect = this._def.effect || null;
		const checkCtx = {
			addIssue: (arg) => {
				addIssueToContext(ctx, arg);
				if (arg.fatal) status.abort();
				else status.dirty();
			},
			get path() {
				return ctx.path;
			}
		};
		checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
		if (effect.type === "preprocess") {
			const processed = effect.transform(ctx.data, checkCtx);
			if (ctx.common.async) return Promise.resolve(processed).then(async (processed) => {
				if (status.value === "aborted") return INVALID;
				const result = await this._def.schema._parseAsync({
					data: processed,
					path: ctx.path,
					parent: ctx
				});
				if (result.status === "aborted") return INVALID;
				if (result.status === "dirty") return DIRTY(result.value);
				if (status.value === "dirty") return DIRTY(result.value);
				return result;
			});
			else {
				if (status.value === "aborted") return INVALID;
				const result = this._def.schema._parseSync({
					data: processed,
					path: ctx.path,
					parent: ctx
				});
				if (result.status === "aborted") return INVALID;
				if (result.status === "dirty") return DIRTY(result.value);
				if (status.value === "dirty") return DIRTY(result.value);
				return result;
			}
		}
		if (effect.type === "refinement") {
			const executeRefinement = (acc) => {
				const result = effect.refinement(acc, checkCtx);
				if (ctx.common.async) return Promise.resolve(result);
				if (result instanceof Promise) throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
				return acc;
			};
			if (ctx.common.async === false) {
				const inner = this._def.schema._parseSync({
					data: ctx.data,
					path: ctx.path,
					parent: ctx
				});
				if (inner.status === "aborted") return INVALID;
				if (inner.status === "dirty") status.dirty();
				executeRefinement(inner.value);
				return {
					status: status.value,
					value: inner.value
				};
			} else return this._def.schema._parseAsync({
				data: ctx.data,
				path: ctx.path,
				parent: ctx
			}).then((inner) => {
				if (inner.status === "aborted") return INVALID;
				if (inner.status === "dirty") status.dirty();
				return executeRefinement(inner.value).then(() => {
					return {
						status: status.value,
						value: inner.value
					};
				});
			});
		}
		if (effect.type === "transform") if (ctx.common.async === false) {
			const base = this._def.schema._parseSync({
				data: ctx.data,
				path: ctx.path,
				parent: ctx
			});
			if (!isValid(base)) return INVALID;
			const result = effect.transform(base.value, checkCtx);
			if (result instanceof Promise) throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
			return {
				status: status.value,
				value: result
			};
		} else return this._def.schema._parseAsync({
			data: ctx.data,
			path: ctx.path,
			parent: ctx
		}).then((base) => {
			if (!isValid(base)) return INVALID;
			return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
				status: status.value,
				value: result
			}));
		});
		util.assertNever(effect);
	}
};
ZodEffects.create = (schema, effect, params) => {
	return new ZodEffects({
		schema,
		typeName: ZodFirstPartyTypeKind.ZodEffects,
		effect,
		...processCreateParams(params)
	});
};
ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
	return new ZodEffects({
		schema,
		effect: {
			type: "preprocess",
			transform: preprocess
		},
		typeName: ZodFirstPartyTypeKind.ZodEffects,
		...processCreateParams(params)
	});
};
var ZodOptional = class extends ZodType {
	_parse(input) {
		if (this._getType(input) === ZodParsedType.undefined) return OK(void 0);
		return this._def.innerType._parse(input);
	}
	unwrap() {
		return this._def.innerType;
	}
};
ZodOptional.create = (type, params) => {
	return new ZodOptional({
		innerType: type,
		typeName: ZodFirstPartyTypeKind.ZodOptional,
		...processCreateParams(params)
	});
};
var ZodNullable = class extends ZodType {
	_parse(input) {
		if (this._getType(input) === ZodParsedType.null) return OK(null);
		return this._def.innerType._parse(input);
	}
	unwrap() {
		return this._def.innerType;
	}
};
ZodNullable.create = (type, params) => {
	return new ZodNullable({
		innerType: type,
		typeName: ZodFirstPartyTypeKind.ZodNullable,
		...processCreateParams(params)
	});
};
var ZodDefault = class extends ZodType {
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		let data = ctx.data;
		if (ctx.parsedType === ZodParsedType.undefined) data = this._def.defaultValue();
		return this._def.innerType._parse({
			data,
			path: ctx.path,
			parent: ctx
		});
	}
	removeDefault() {
		return this._def.innerType;
	}
};
ZodDefault.create = (type, params) => {
	return new ZodDefault({
		innerType: type,
		typeName: ZodFirstPartyTypeKind.ZodDefault,
		defaultValue: typeof params.default === "function" ? params.default : () => params.default,
		...processCreateParams(params)
	});
};
var ZodCatch = class extends ZodType {
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		const newCtx = {
			...ctx,
			common: {
				...ctx.common,
				issues: []
			}
		};
		const result = this._def.innerType._parse({
			data: newCtx.data,
			path: newCtx.path,
			parent: { ...newCtx }
		});
		if (isAsync(result)) return result.then((result) => {
			return {
				status: "valid",
				value: result.status === "valid" ? result.value : this._def.catchValue({
					get error() {
						return new ZodError(newCtx.common.issues);
					},
					input: newCtx.data
				})
			};
		});
		else return {
			status: "valid",
			value: result.status === "valid" ? result.value : this._def.catchValue({
				get error() {
					return new ZodError(newCtx.common.issues);
				},
				input: newCtx.data
			})
		};
	}
	removeCatch() {
		return this._def.innerType;
	}
};
ZodCatch.create = (type, params) => {
	return new ZodCatch({
		innerType: type,
		typeName: ZodFirstPartyTypeKind.ZodCatch,
		catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
		...processCreateParams(params)
	});
};
var ZodNaN = class extends ZodType {
	_parse(input) {
		if (this._getType(input) !== ZodParsedType.nan) {
			const ctx = this._getOrReturnCtx(input);
			addIssueToContext(ctx, {
				code: ZodIssueCode.invalid_type,
				expected: ZodParsedType.nan,
				received: ctx.parsedType
			});
			return INVALID;
		}
		return {
			status: "valid",
			value: input.data
		};
	}
};
ZodNaN.create = (params) => {
	return new ZodNaN({
		typeName: ZodFirstPartyTypeKind.ZodNaN,
		...processCreateParams(params)
	});
};
var ZodBranded = class extends ZodType {
	_parse(input) {
		const { ctx } = this._processInputParams(input);
		const data = ctx.data;
		return this._def.type._parse({
			data,
			path: ctx.path,
			parent: ctx
		});
	}
	unwrap() {
		return this._def.type;
	}
};
var ZodPipeline = class ZodPipeline extends ZodType {
	_parse(input) {
		const { status, ctx } = this._processInputParams(input);
		if (ctx.common.async) {
			const handleAsync = async () => {
				const inResult = await this._def.in._parseAsync({
					data: ctx.data,
					path: ctx.path,
					parent: ctx
				});
				if (inResult.status === "aborted") return INVALID;
				if (inResult.status === "dirty") {
					status.dirty();
					return DIRTY(inResult.value);
				} else return this._def.out._parseAsync({
					data: inResult.value,
					path: ctx.path,
					parent: ctx
				});
			};
			return handleAsync();
		} else {
			const inResult = this._def.in._parseSync({
				data: ctx.data,
				path: ctx.path,
				parent: ctx
			});
			if (inResult.status === "aborted") return INVALID;
			if (inResult.status === "dirty") {
				status.dirty();
				return {
					status: "dirty",
					value: inResult.value
				};
			} else return this._def.out._parseSync({
				data: inResult.value,
				path: ctx.path,
				parent: ctx
			});
		}
	}
	static create(a, b) {
		return new ZodPipeline({
			in: a,
			out: b,
			typeName: ZodFirstPartyTypeKind.ZodPipeline
		});
	}
};
var ZodReadonly = class extends ZodType {
	_parse(input) {
		const result = this._def.innerType._parse(input);
		const freeze = (data) => {
			if (isValid(data)) data.value = Object.freeze(data.value);
			return data;
		};
		return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
	}
	unwrap() {
		return this._def.innerType;
	}
};
ZodReadonly.create = (type, params) => {
	return new ZodReadonly({
		innerType: type,
		typeName: ZodFirstPartyTypeKind.ZodReadonly,
		...processCreateParams(params)
	});
};
ZodObject.lazycreate;
var ZodFirstPartyTypeKind;
(function(ZodFirstPartyTypeKind) {
	ZodFirstPartyTypeKind["ZodString"] = "ZodString";
	ZodFirstPartyTypeKind["ZodNumber"] = "ZodNumber";
	ZodFirstPartyTypeKind["ZodNaN"] = "ZodNaN";
	ZodFirstPartyTypeKind["ZodBigInt"] = "ZodBigInt";
	ZodFirstPartyTypeKind["ZodBoolean"] = "ZodBoolean";
	ZodFirstPartyTypeKind["ZodDate"] = "ZodDate";
	ZodFirstPartyTypeKind["ZodSymbol"] = "ZodSymbol";
	ZodFirstPartyTypeKind["ZodUndefined"] = "ZodUndefined";
	ZodFirstPartyTypeKind["ZodNull"] = "ZodNull";
	ZodFirstPartyTypeKind["ZodAny"] = "ZodAny";
	ZodFirstPartyTypeKind["ZodUnknown"] = "ZodUnknown";
	ZodFirstPartyTypeKind["ZodNever"] = "ZodNever";
	ZodFirstPartyTypeKind["ZodVoid"] = "ZodVoid";
	ZodFirstPartyTypeKind["ZodArray"] = "ZodArray";
	ZodFirstPartyTypeKind["ZodObject"] = "ZodObject";
	ZodFirstPartyTypeKind["ZodUnion"] = "ZodUnion";
	ZodFirstPartyTypeKind["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
	ZodFirstPartyTypeKind["ZodIntersection"] = "ZodIntersection";
	ZodFirstPartyTypeKind["ZodTuple"] = "ZodTuple";
	ZodFirstPartyTypeKind["ZodRecord"] = "ZodRecord";
	ZodFirstPartyTypeKind["ZodMap"] = "ZodMap";
	ZodFirstPartyTypeKind["ZodSet"] = "ZodSet";
	ZodFirstPartyTypeKind["ZodFunction"] = "ZodFunction";
	ZodFirstPartyTypeKind["ZodLazy"] = "ZodLazy";
	ZodFirstPartyTypeKind["ZodLiteral"] = "ZodLiteral";
	ZodFirstPartyTypeKind["ZodEnum"] = "ZodEnum";
	ZodFirstPartyTypeKind["ZodEffects"] = "ZodEffects";
	ZodFirstPartyTypeKind["ZodNativeEnum"] = "ZodNativeEnum";
	ZodFirstPartyTypeKind["ZodOptional"] = "ZodOptional";
	ZodFirstPartyTypeKind["ZodNullable"] = "ZodNullable";
	ZodFirstPartyTypeKind["ZodDefault"] = "ZodDefault";
	ZodFirstPartyTypeKind["ZodCatch"] = "ZodCatch";
	ZodFirstPartyTypeKind["ZodPromise"] = "ZodPromise";
	ZodFirstPartyTypeKind["ZodBranded"] = "ZodBranded";
	ZodFirstPartyTypeKind["ZodPipeline"] = "ZodPipeline";
	ZodFirstPartyTypeKind["ZodReadonly"] = "ZodReadonly";
})(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
var stringType = ZodString.create;
var numberType = ZodNumber.create;
ZodNaN.create;
ZodBigInt.create;
var booleanType = ZodBoolean.create;
ZodDate.create;
ZodSymbol.create;
ZodUndefined.create;
ZodNull.create;
ZodAny.create;
ZodUnknown.create;
ZodNever.create;
ZodVoid.create;
var arrayType = ZodArray.create;
var objectType = ZodObject.create;
ZodObject.strictCreate;
ZodUnion.create;
var discriminatedUnionType = ZodDiscriminatedUnion.create;
ZodIntersection.create;
ZodTuple.create;
var recordType = ZodRecord.create;
ZodMap.create;
ZodSet.create;
ZodFunction.create;
ZodLazy.create;
var literalType = ZodLiteral.create;
var enumType = ZodEnum.create;
ZodNativeEnum.create;
ZodPromise.create;
ZodEffects.create;
ZodOptional.create;
ZodNullable.create;
ZodEffects.createWithPreprocess;
ZodPipeline.create;
//#endregion
//#region lib/activity.ts
function liveStudyLogs(state) {
	const resources = new Map(state.resources.map((r) => [r.id, new Set(r.lessons.map((l) => l.id))]));
	const removed = new Set(state.activityRemovals.filter((e) => e.kind === "log" || e.kind === "resource").map((e) => e.kind + ":" + e.targetId));
	const resets = new Map(state.activityRemovals.filter((e) => e.kind === "lesson").map((e) => [e.targetId, e.at]));
	return state.studyLog.filter((l) => resources.get(l.resourceId)?.has(l.lessonId) && !removed.has("resource:" + l.resourceId) && !removed.has("log:" + l.id) && (!resets.has(l.lessonId) || l.at > resets.get(l.lessonId)));
}
function invalidateReviews(state) {
	return {
		...state,
		coach: {
			...state.coach,
			sessions: state.coach.sessions.map((s) => ({
				...s,
				reply: null,
				aiStatus: "off",
				aiError: "",
				nextStep: ""
			}))
		}
	};
}
/** Repair dangling legacy activity and enforce removals after restore, save and Wi-Fi merge. */
function normalizeActivity(state) {
	const removedResources = new Set(state.activityRemovals.filter((e) => e.kind === "resource").map((e) => e.targetId));
	const resources = state.resources.filter((r) => !removedResources.has(r.id));
	const refs = new Map(resources.map((r) => [r.id, new Set(r.lessons.map((l) => l.id))]));
	const studyLog = liveStudyLogs({
		...state,
		resources
	});
	const resetAt = new Map(state.activityRemovals.filter((e) => e.kind === "lesson").map((e) => [e.targetId, e.at]));
	const removedSessions = new Set(state.activityRemovals.filter((e) => e.kind === "session").map((e) => e.targetId));
	const removedLogs = new Set(state.activityRemovals.filter((e) => e.kind === "log").map((e) => e.targetId));
	const touched = new Set([...resetAt.keys(), ...state.activityRemovals.filter((e) => e.kind === "log" && e.lessonId).map((e) => e.lessonId)]);
	const totals = /* @__PURE__ */ new Map();
	for (const l of studyLog) totals.set(l.lessonId, (totals.get(l.lessonId) || 0) + l.minutes);
	const sessions = state.coach.sessions.filter((s) => refs.get(s.resourceId)?.has(s.lessonId) && !removedSessions.has(s.id) && !removedLogs.has(s.id) && (!resetAt.has(s.lessonId) || s.at > resetAt.get(s.lessonId)));
	const lessonIds = new Set(resources.flatMap((r) => r.lessons.map((l) => l.id)));
	const chosen = state.coach.todayPlan?.lessonIds.filter((id) => lessonIds.has(id)) || [];
	let result = {
		...state,
		resources: resources.map((r) => ({
			...r,
			lessons: r.lessons.map((l) => {
				if (!touched.has(l.id)) return l;
				const studiedMinutes = Math.min(l.minutes, totals.get(l.id) || 0), done = studiedMinutes >= l.minutes;
				return {
					...l,
					studiedMinutes,
					done,
					completedAt: done ? studyLog.filter((log) => log.lessonId === l.id).map((log) => log.at).sort().at(-1) || null : null
				};
			})
		})),
		studyLog,
		coach: {
			...state.coach,
			sessions,
			todayPlan: state.coach.todayPlan && chosen.length ? {
				...state.coach.todayPlan,
				lessonIds: chosen
			} : null
		}
	};
	if (studyLog.length !== state.studyLog.length || sessions.length !== state.coach.sessions.length) result = invalidateReviews(result);
	return result;
}
//#endregion
//#region lib/youtube.ts
var videoId = /^[A-Za-z0-9_-]{11}$/;
function youtubeLink(value) {
	let u;
	try {
		u = new URL(value);
	} catch {
		return null;
	}
	if (!["https:", "http:"].includes(u.protocol) || u.username || u.password || u.port) return null;
	const host = u.hostname.toLowerCase().replace(/^www\./, "");
	if (![
		"youtube.com",
		"m.youtube.com",
		"music.youtube.com",
		"youtu.be"
	].includes(host)) return null;
	const list = u.searchParams.get("list");
	if (list) {
		if (!/^[A-Za-z0-9_-]{2,150}$/.test(list)) throw Error("Check the YouTube playlist link.");
		return {
			kind: "playlist",
			id: list,
			url: "https://www.youtube.com/playlist?list=" + list
		};
	}
	const id = host === "youtu.be" ? u.pathname.split("/")[1] : u.searchParams.get("v") || u.pathname.match(/^\/(?:shorts|embed|live)\/([^/]+)/)?.[1];
	if (!id || !videoId.test(id)) throw Error("Paste a YouTube playlist or video link.");
	return {
		kind: "video",
		id,
		url: "https://www.youtube.com/watch?v=" + id
	};
}
function youtubeThumbnail(id) {
	return videoId.test(id) ? "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg" : "";
}
function safeThumbnail(value) {
	try {
		const u = new URL(value);
		return u.protocol === "https:" && u.hostname === "i.ytimg.com" && !u.port && !u.username && !u.password && /^\/vi\/[A-Za-z0-9_-]{11}\/(?:hqdefault|mqdefault|sddefault|maxresdefault)\.jpg$/.test(u.pathname) ? u.origin + u.pathname : "";
	} catch {
		return "";
	}
}
function text$1(v) {
	return (typeof v === "string" ? v : v?.simpleText || v?.content || v?.runs?.map((r) => r.text || "").join("") || "").trim();
}
function collect(v, key, out = []) {
	if (!v || typeof v !== "object") return out;
	if (Array.isArray(v)) for (const x of v) collect(x, key, out);
	else {
		if (v[key]) out.push(v[key]);
		for (const x of Object.values(v)) collect(x, key, out);
	}
	return out;
}
function embeddedJson(html, name) {
	const match = new RegExp("(?:var\\s+)?" + name + "\\s*=\\s*").exec(html);
	if (!match) throw Error("YouTube did not expose a public outline. Try Browser capture on the loaded playlist.");
	const start = match.index + match[0].length;
	let depth = 0, quoted = false, escape = false;
	for (let i = start; i < html.length; i++) {
		const c = html[i];
		if (quoted) {
			if (escape) escape = false;
			else if (c === "\\") escape = true;
			else if (c === "\"") quoted = false;
		} else if (c === "\"") quoted = true;
		else if (c === "{") depth++;
		else if (c === "}" && !--depth) return JSON.parse(html.slice(start, i + 1));
	}
	throw Error("YouTube returned an incomplete outline. Please retry.");
}
function seconds(value) {
	if (!/^\d{1,3}(?::\d{2}){1,2}$/.test(value)) return 0;
	return value.split(":").reduce((n, x) => n * 60 + Number(x), 0);
}
function lesson(id, title, duration) {
	if (!videoId.test(id) || !title || /^\[?(?:private|deleted) video\]?$/i.test(title)) return null;
	return {
		title: title.slice(0, 250),
		url: "https://www.youtube.com/watch?v=" + id,
		sourceId: "youtube:" + id,
		minutes: duration ? Math.min(600, Math.max(1, Math.ceil(duration / 60))) : 15,
		durationSeconds: duration,
		durationEstimated: !duration || duration > 36e3,
		thumbnailUrl: youtubeThumbnail(id),
		format: "video",
		modulePath: ""
	};
}
function parsePlaylistPage(data, playlistId) {
	const root = data.contents || data.onResponseReceivedActions || data.onResponseReceivedEndpoints || data.continuationContents || data;
	const lessons = [];
	const visit = (v) => {
		if (!v || typeof v !== "object") return;
		if (Array.isArray(v)) {
			for (const x of v) visit(x);
			return;
		}
		if (v.playlistVideoRenderer) {
			const x = v.playlistVideoRenderer;
			const l = lesson(x.videoId, text$1(x.title), Number(x.lengthSeconds) || seconds(text$1(x.lengthText)));
			if (l && x.isPlayable !== false) lessons.push(l);
			return;
		}
		if (v.lockupViewModel) {
			const x = v.lockupViewModel;
			const endpoint = x.rendererContext?.commandContext?.onTap?.innertubeCommand?.watchEndpoint;
			if (x.contentType === "LOCKUP_CONTENT_TYPE_VIDEO" && endpoint?.playlistId === playlistId) {
				const duration = collect(x.contentImage, "thumbnailBadgeViewModel").map((b) => seconds(text$1(b.text))).find(Boolean) || 0;
				const l = lesson(x.contentId, text$1(x.metadata?.lockupMetadataViewModel?.title), duration);
				if (l) lessons.push(l);
			}
			return;
		}
		for (const x of Object.values(v)) visit(x);
	};
	visit(root);
	return {
		lessons,
		token: [...collect(root, "continuationItemRenderer"), ...collect(root, "continuationItemViewModel")].flatMap((x) => collect(x, "continuationCommand")).map((x) => x.token).find((x) => typeof x === "string") || ""
	};
}
function expectedCount(data) {
	for (const sidebar of collect(data.sidebar, "playlistSidebarPrimaryInfoRenderer")) for (const stat of sidebar.stats || []) {
		const m = text$1(stat).match(/^([\d,]+)\s+videos?$/i);
		if (m) return Number(m[1].replaceAll(",", ""));
	}
	return null;
}
async function importYouTube(value, transport = fetchYouTube) {
	const started = Date.now();
	const link = youtubeLink(value);
	if (!link) throw Error("Use a YouTube playlist or video link.");
	const html = await transport({
		kind: link.kind,
		id: link.id
	});
	let title = "", provider = "YouTube", lessons = [], totalItems = null, complete = true;
	if (link.kind === "video") {
		const d = embeddedJson(html, "ytInitialPlayerResponse").videoDetails;
		if (!d?.title) throw Error("This video is unavailable publicly. Use Browser capture or enter its details manually.");
		const l = lesson(link.id, d.title, Number(d.lengthSeconds) || 0);
		if (!l) throw Error("This video is unavailable.");
		lessons = [l];
		title = d.title;
		provider = (d.author ? d.author + " · " : "") + "YouTube";
		totalItems = 1;
	} else {
		const data = embeddedJson(html, "ytInitialData");
		title = text$1(data.metadata?.playlistMetadataRenderer?.title) || text$1(collect(data.sidebar, "playlistSidebarPrimaryInfoRenderer")[0]?.title);
		if (!title) throw Error("This playlist is unavailable publicly. Check its link or use Browser capture.");
		const owner = collect(data.sidebar, "videoOwnerRenderer")[0];
		provider = (text$1(owner?.title) ? text$1(owner.title) + " · " : "") + "YouTube";
		totalItems = expectedCount(data);
		const first = parsePlaylistPage(data, link.id);
		lessons = first.lessons;
		let token = first.token;
		const tokens = /* @__PURE__ */ new Set();
		const version = html.match(/"INNERTUBE_CLIENT_VERSION"\s*:\s*"([\w.]+)"/)?.[1] || "2.20261001.00.00";
		for (let page = 0; token && lessons.length < 500 && !(totalItems !== null && lessons.length >= totalItems) && page < 9; page++) {
			if (tokens.has(token) || Date.now() - started > 33e3) {
				complete = false;
				break;
			}
			tokens.add(token);
			try {
				const next = parsePlaylistPage(JSON.parse(await transport({
					kind: "continuation",
					token,
					clientVersion: version
				})), link.id);
				if (!next.lessons.length) {
					complete = false;
					break;
				}
				lessons.push(...next.lessons);
				token = next.token;
			} catch {
				complete = false;
				break;
			}
		}
		if (token && !(totalItems !== null && lessons.length >= totalItems) || totalItems !== null && lessons.length < totalItems || lessons.length > 500) complete = false;
	}
	const unique = [...new Map(lessons.map((l) => [l.sourceId, l])).values()].slice(0, 500);
	if (!unique.length) throw Error("No public playlist videos were found. Use Browser capture on the loaded playlist; no placeholder was added.");
	const estimated = unique.filter((l) => l.durationEstimated).length;
	const duplicateCount = lessons.length - unique.length;
	const notice = [
		`${unique.length}${totalItems !== null ? " of " + totalItems : ""} ${link.kind === "playlist" ? "playlist videos" : "video"} loaded in source order.`,
		complete ? "" : "Partial outline: some videos are private, unavailable, or could not be loaded. You can retry later.",
		duplicateCount ? `${duplicateCount} repeated entries combined.` : "",
		estimated ? `${estimated} durations need review (15 min when unknown; planning durations above 10 hours are capped).` : "Durations come from YouTube; planning minutes round up.",
		"Thumbnails and source links included."
	].filter(Boolean).join(" ");
	return {
		title: title.slice(0, 250),
		provider: provider.slice(0, 100),
		kind: link.kind === "playlist" ? "course" : "video",
		url: link.url,
		thumbnailUrl: unique[0].thumbnailUrl,
		lessons: unique,
		totalItems,
		complete,
		captureScope: complete ? "course" : "page",
		captureNote: notice,
		notice
	};
}
function youtubeFetchSpec(request) {
	if (request.kind === "continuation") {
		if (!request.token || request.token.length > 15e3 || !request.clientVersion || !/^[\w.]{1,80}$/.test(request.clientVersion)) throw Error("Invalid playlist continuation.");
		return {
			url: "https://www.youtube.com/youtubei/v1/browse",
			init: {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					context: { client: {
						clientName: "WEB",
						clientVersion: request.clientVersion,
						hl: "en",
						gl: "US"
					} },
					continuation: request.token
				})
			}
		};
	}
	if (!request.id || (request.kind === "video" ? !videoId.test(request.id) : request.kind !== "playlist" || !/^[A-Za-z0-9_-]{2,150}$/.test(request.id))) throw Error("Invalid YouTube link.");
	return {
		url: "https://www.youtube.com/" + (request.kind === "playlist" ? "playlist?list=" : "watch?v=") + request.id + "&hl=en",
		init: {}
	};
}
async function fetchYouTube(request) {
	const spec = youtubeFetchSpec(request);
	const response = await fetch(spec.url, {
		...spec.init,
		redirect: "manual",
		credentials: "omit",
		headers: {
			...spec.init.headers,
			"User-Agent": "Mozilla/5.0",
			"Accept-Language": "en-US,en;q=0.9"
		},
		signal: AbortSignal.timeout(12e3)
	});
	if (!response.ok) throw Error("YouTube could not be reached. Try again or use Browser capture.");
	if (Number(response.headers.get("Content-Length")) > 6e6) throw Error("YouTube’s outline is too large. Use Browser capture.");
	const reader = response.body?.getReader();
	if (!reader) throw Error("Empty YouTube response.");
	let size = 0, result = "";
	const decoder = new TextDecoder();
	try {
		while (true) {
			const { done, value } = await reader.read();
			if (done) break;
			size += value.byteLength;
			if (size > 6e6) throw Error("YouTube’s outline is too large. Use Browser capture.");
			result += decoder.decode(value, { stream: true });
		}
		return result + decoder.decode();
	} finally {
		await reader.cancel();
	}
}
//#endregion
//#region lib/coach-action-schema.ts
var text = (max) => stringType().trim().min(1).max(max), ref = stringType().max(100), space = enumType(["personal", "work"]), reason = stringType().max(500), link = stringType().max(2e3).refine((s) => {
	try {
		const u = new URL(s);
		return ["http:", "https:"].includes(u.protocol) && !u.username && !u.password;
	} catch {
		return !s;
	}
}, "Use a valid web URL");
var key = text(60).regex(/^[a-zA-Z0-9_-]+$/), day = stringType().max(10).refine((s) => !s || /^\d{4}-\d{2}-\d{2}$/.test(s) && (/* @__PURE__ */ new Date(s + "T12:00:00Z")).toISOString().slice(0, 10) === s, "Use a valid date");
var coachActionsSchema = arrayType(discriminatedUnionType("type", [
	objectType({
		type: literalType("create_goal"),
		key,
		workspace: space,
		title: text(120),
		description: stringType().max(500),
		importance: numberType().int().min(1).max(5),
		reason
	}),
	objectType({
		type: literalType("create_resource"),
		key,
		workspace: space,
		title: text(250),
		kind: enumType([
			"course",
			"video",
			"article",
			"topic",
			"book"
		]),
		url: link,
		goalRef: ref,
		folderPath: stringType().max(200),
		priority: numberType().int().min(1).max(5),
		outlineSource: enumType(["generated", "provided"]),
		lessons: arrayType(objectType({
			title: text(250),
			minutes: numberType().int().min(1).max(600),
			modulePath: stringType().max(200),
			url: link,
			format: enumType([
				"video",
				"reading",
				"exercise"
			])
		})).min(1).max(40),
		reason
	}),
	objectType({
		type: literalType("organize_resource"),
		resourceId: text(100),
		folderPath: stringType().max(200),
		goalRef: ref,
		priority: numberType().int().min(1).max(5),
		reason
	}),
	objectType({
		type: literalType("create_todo"),
		key,
		workspace: space,
		title: text(200),
		goalRef: ref,
		dueDay: day,
		reason
	}),
	objectType({
		type: literalType("file_capture"),
		captureId: text(100),
		reason
	}),
	objectType({
		type: literalType("set_daily_goal"),
		workspace: space,
		minutes: numberType().int().min(10).max(480),
		reason
	}),
	objectType({
		type: literalType("set_focus_goal"),
		workspace: space,
		goalRef: text(100),
		reason
	}),
	objectType({
		type: literalType("set_today_plan"),
		workspace: space,
		minutes: numberType().int().min(1).max(480),
		resourceRefs: arrayType(text(100)).min(1).max(12),
		reason
	}),
	objectType({
		type: literalType("log_learning"),
		key,
		workspace: space,
		title: text(250),
		minutes: numberType().int().min(1).max(600),
		url: link,
		reflection: stringType().max(1e3),
		reason
	})
])).max(12);
var actionReceiptSchema = objectType({
	changes: arrayType(objectType({
		collection: enumType([
			"resources",
			"goals",
			"todos",
			"inbox",
			"studyLog",
			"sessions",
			"settings",
			"todayPlan"
		]),
		id: text(100),
		before: stringType().max(16e4).nullable(),
		after: stringType().max(16e4).nullable()
	})).max(120),
	undoneAt: stringType().datetime().nullable().default(null)
});
var str = (max) => ({
	type: "string",
	maxLength: max
}), obj = (properties) => ({
	type: "object",
	properties,
	required: Object.keys(properties),
	additionalProperties: false
}), integer = (min, max) => ({
	type: "integer",
	minimum: min,
	maximum: max
}), en = (values) => ({
	type: "string",
	enum: values
});
var base = {
	workspace: en(["personal", "work"]),
	reason: str(500)
}, create = {
	...base,
	key: str(60)
};
var variant = (type, fields) => obj({
	type: en([type]),
	...fields
});
variant("create_goal", {
	...create,
	title: str(120),
	description: str(500),
	importance: integer(1, 5)
}), variant("create_resource", {
	...create,
	title: str(250),
	kind: en([
		"course",
		"video",
		"article",
		"topic",
		"book"
	]),
	url: str(2e3),
	goalRef: str(100),
	folderPath: str(200),
	priority: integer(1, 5),
	outlineSource: en(["generated", "provided"]),
	lessons: {
		type: "array",
		minItems: 1,
		maxItems: 40,
		items: obj({
			title: str(250),
			minutes: integer(1, 600),
			modulePath: str(200),
			url: str(2e3),
			format: en([
				"video",
				"reading",
				"exercise"
			])
		})
	}
}), variant("organize_resource", {
	resourceId: str(100),
	folderPath: str(200),
	goalRef: str(100),
	priority: integer(1, 5),
	reason: str(500)
}), variant("create_todo", {
	...create,
	title: str(200),
	goalRef: str(100),
	dueDay: str(10)
}), variant("file_capture", {
	captureId: str(100),
	reason: str(500)
}), variant("set_daily_goal", {
	...base,
	minutes: integer(10, 480)
}), variant("set_focus_goal", {
	...base,
	goalRef: str(100)
}), variant("set_today_plan", {
	...base,
	minutes: integer(1, 480),
	resourceRefs: {
		type: "array",
		minItems: 1,
		maxItems: 12,
		items: str(100)
	}
}), variant("log_learning", {
	...create,
	title: str(250),
	minutes: integer(1, 600),
	url: str(2e3),
	reflection: str(1e3)
});
//#endregion
//#region lib/coach-schema.ts
var coachSuggestionSchema = objectType({
	resourceId: stringType().min(1).max(100),
	priority: numberType().int().min(1).max(5),
	focusModule: stringType().max(200),
	reason: stringType().max(700)
});
var coachPlanSchema = objectType({
	minutes: numberType().int().min(1).max(480),
	lessonIds: arrayType(stringType().min(1).max(100)).min(1).max(12),
	reason: stringType().max(700)
});
var memoryKindSchema = enumType([
	"goal",
	"preference",
	"constraint",
	"fact"
]);
var memoryProposalSchema = objectType({
	text: stringType().trim().min(1).max(400),
	kind: memoryKindSchema,
	reason: stringType().max(400)
});
var coachMemorySchema = objectType({
	id: stringType().min(1).max(100),
	text: stringType().trim().min(1).max(400),
	kind: memoryKindSchema,
	workspace: enumType([
		"all",
		"personal",
		"work"
	]).default("all"),
	source: enumType(["manual", "coach"]),
	createdAt: stringType().datetime()
});
var coachReplySchema = objectType({
	message: stringType().min(1).max(4e3),
	question: stringType().max(500).default(""),
	suggestions: arrayType(coachSuggestionSchema).max(12),
	todayPlan: coachPlanSchema.nullable().default(null),
	suggestedMemories: arrayType(memoryProposalSchema).max(3).optional(),
	actions: coachActionsSchema.optional()
});
var coachMessageSchema = objectType({
	id: stringType().min(1).max(100),
	role: enumType(["user", "assistant"]),
	text: stringType().min(1).max(6e3),
	at: stringType().datetime(),
	source: enumType([
		"learner",
		"smart",
		"ai"
	]),
	context: stringType().max(2e3).default(""),
	reply: coachReplySchema.nullable().default(null),
	appliedAt: stringType().datetime().nullable().default(null),
	actionReceipt: actionReceiptSchema.optional(),
	actionGuard: stringType().max(3e4).optional(),
	actionScope: enumType([
		"all",
		"personal",
		"work"
	]).optional()
});
var studySessionSchema = objectType({
	id: stringType().min(1).max(100),
	at: stringType().datetime(),
	resourceId: stringType().max(100),
	lessonId: stringType().max(100),
	resourceTitle: stringType().max(250),
	lessonTitle: stringType().max(250),
	minutes: numberType().int().min(1).max(600),
	plannedMinutes: numberType().int().min(1).max(600),
	completed: booleanType(),
	timeSource: enumType(["logged", "estimated"]),
	timerSeconds: numberType().int().min(0).max(86400),
	difficulty: enumType([
		"unknown",
		"easy",
		"stretch",
		"stuck"
	]),
	reflection: stringType().max(1e3),
	goal: stringType().max(120),
	focusGoal: stringType().max(120),
	recommended: objectType({
		resourceId: stringType().max(100),
		lessonId: stringType().max(100),
		resourceTitle: stringType().max(250),
		lessonTitle: stringType().max(250),
		reason: stringType().max(300)
	}).nullable(),
	verdict: enumType([
		"aligned",
		"detour",
		"unplanned"
	]),
	summary: stringType().max(2e3),
	nextStep: stringType().max(1e3),
	aiStatus: enumType([
		"off",
		"queued",
		"ready",
		"error"
	]).default("off"),
	aiError: stringType().max(500).default(""),
	reply: coachReplySchema.nullable().default(null)
});
var dailyCoachReplySchema = objectType({
	headline: stringType().min(1).max(180),
	assessment: stringType().min(1).max(5e3),
	nextAction: stringType().min(1).max(1200),
	checkpoint: stringType().max(2400),
	question: stringType().max(500)
});
var dailyCoachReviewSchema = objectType({
	id: stringType().min(1).max(160),
	day: stringType().regex(/^\d{4}-\d{2}-\d{2}$/),
	timezone: stringType().max(100),
	at: stringType().datetime(),
	source: enumType(["phone", "web"]),
	activitySignature: stringType().max(100),
	snapshotAt: stringType().datetime(),
	requestVersion: numberType().int().min(1).max(100).default(1),
	reply: dailyCoachReplySchema
});
var coachStateSchema = objectType({
	contextVersion: numberType().int().min(0).max(1).default(0),
	contextMode: enumType(["automatic", "selected"]).default("automatic"),
	dailyEnabled: booleanType().default(true),
	dailyReviews: arrayType(dailyCoachReviewSchema).max(60).default([]),
	tone: enumType(["direct", "balanced"]).default("direct"),
	useScreenTime: booleanType().default(true),
	memories: arrayType(coachMemorySchema).max(40).refine((a) => new Set(a.map((x) => x.id)).size === a.length, "Duplicate memory IDs").default([]),
	autoReviews: booleanType().default(false),
	sessions: arrayType(studySessionSchema).max(120).default([]),
	memory: objectType({
		learningIntent: stringType().max(1e3).default(""),
		preferences: stringType().max(1e3).default("")
	}).default({}),
	conversations: arrayType(objectType({
		id: stringType().min(1).max(100),
		title: stringType().min(1).max(100),
		createdAt: stringType().datetime(),
		contextSelection: objectType({
			workspace: enumType([
				"all",
				"personal",
				"work"
			]),
			inboxIds: arrayType(stringType().min(1).max(100)).max(8)
		}).optional(),
		messages: arrayType(coachMessageSchema).max(40)
	})).max(8).default([]),
	todayPlan: objectType({
		day: stringType().regex(/^\d{4}-\d{2}-\d{2}$/),
		minutes: numberType().int().min(1).max(480),
		lessonIds: arrayType(stringType().min(1).max(100)).max(12)
	}).nullable().default(null)
}).default({});
//#endregion
//#region lib/screen-time-schema.ts
var date = stringType().refine((s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && Number.isFinite(Date.parse(s + "T12:00:00Z")) && (/* @__PURE__ */ new Date(s + "T12:00:00Z")).toISOString().slice(0, 10) === s, "Invalid date");
var usageMeasurementSchema = objectType({
	method: enumType([
		"legacy",
		"activity-timeline-v2",
		"unlocked-screen-v1",
		"mac-foreground-v1"
	]),
	appActivityMinutes: numberType().min(0).max(1500).optional(),
	unlockedMinutes: numberType().min(0).max(1500).nullable().optional(),
	completeScreenEvents: booleanType().optional(),
	eventCount: numberType().int().min(0).max(25e4).optional(),
	firstEventAt: stringType().datetime().optional(),
	lastEventAt: stringType().datetime().optional()
});
var namedApps = arrayType(objectType({
	name: stringType().max(120),
	minutes: numberType().min(0).max(1500)
})).max(5);
var screenSummarySchema = objectType({
	id: stringType().min(1).max(160),
	deviceId: stringType().min(1).max(100),
	deviceName: stringType().min(1).max(80),
	platform: enumType(["android", "mac"]),
	day: date,
	timezone: stringType().max(100),
	capturedAt: stringType().datetime(),
	totalMinutes: numberType().min(0).max(1500),
	learningMinutes: numberType().min(0).max(1500).default(0),
	leisureMinutes: numberType().min(0).max(1500).default(0),
	mixedMinutes: numberType().min(0).max(1500).default(0),
	neutralMinutes: numberType().min(0).max(1500).default(0),
	budgetMinutes: numberType().int().min(5).max(480),
	leisureConfigured: booleanType().default(false),
	partial: booleanType().default(true),
	topLeisureApps: namedApps.default([]),
	topApps: namedApps.default([]),
	measurement: usageMeasurementSchema.optional()
}).refine((s) => s.id === s.deviceId + ":" + s.day, "Invalid summary ID");
//#endregion
//#region lib/learning.ts
var safeUrl = (s) => {
	try {
		const u = new URL(s);
		return ["http:", "https:"].includes(u.protocol) ? u.href : "";
	} catch {
		return "";
	}
};
var thumbnail = stringType().max(2e3).refine((s) => !s || !!safeThumbnail(s), "Use a YouTube thumbnail URL").default("");
var url = stringType().max(2e3).refine((s) => !s || !!safeUrl(s), "Use an http or https link");
var workspaceSchema = enumType(["personal", "work"]).default("personal");
var calendarDay = stringType().refine((s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && Number.isFinite(Date.parse(s + "T12:00:00Z")) && (/* @__PURE__ */ new Date(s + "T12:00:00Z")).toISOString().slice(0, 10) === s, "Use a valid calendar date");
var goalImageSchema = stringType().max(1e5).refine((s) => !s || /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(s), "Choose a JPEG, PNG, or WebP image").default("");
var todoSchema = objectType({
	workspace: workspaceSchema,
	id: stringType().min(1).max(100),
	title: stringType().trim().min(1).max(200),
	goalId: stringType().max(100).default(""),
	dueDay: calendarDay.or(literalType("")).default(""),
	createdAt: stringType().datetime(),
	doneAt: stringType().datetime().nullable().default(null)
});
var rewardSchema = objectType({
	workspace: workspaceSchema,
	id: stringType().min(1).max(100),
	title: stringType().trim().min(1).max(120),
	description: stringType().max(500).default(""),
	image: goalImageSchema,
	metric: enumType(["days", "streak"]).default("days"),
	targetDays: numberType().int().min(1).max(365),
	minimumMinutes: numberType().int().min(1).max(60).default(5),
	startDay: calendarDay,
	createdAt: stringType().datetime(),
	redeemedAt: stringType().datetime().nullable().default(null)
});
var lessonSchema = objectType({
	id: stringType().min(1).max(100),
	title: stringType().min(1).max(250),
	minutes: numberType().int().min(1).max(600),
	thumbnailUrl: thumbnail,
	durationSeconds: numberType().int().min(0).max(604800).default(0),
	durationEstimated: booleanType().default(false),
	url,
	done: booleanType(),
	completedAt: stringType().datetime().nullable(),
	notes: stringType().max(1e4),
	pinned: booleanType().default(false),
	modulePath: stringType().max(200).default(""),
	format: enumType([
		"video",
		"exercise",
		"reading"
	]).default("video"),
	sourceId: stringType().max(2e3).default(""),
	studiedMinutes: numberType().int().min(0).max(600).default(0),
	pageStart: numberType().int().min(1).max(1e5).nullable().default(null),
	pageEnd: numberType().int().min(1).max(1e5).nullable().default(null)
});
var resourceSchema = objectType({
	workspace: workspaceSchema,
	coverImage: goalImageSchema,
	quickLog: booleanType().default(false),
	id: stringType().min(1).max(100),
	title: stringType().min(1).max(250),
	provider: stringType().max(100),
	thumbnailUrl: thumbnail,
	excerpt: stringType().max(2e4).default(""),
	kind: enumType([
		"course",
		"video",
		"article",
		"topic",
		"book"
	]),
	url,
	goalId: stringType().max(100),
	priority: numberType().int().min(1).max(5),
	deadline: stringType().refine((s) => !s || /^\d{4}-\d{2}-\d{2}$/.test(s)),
	color: enumType([
		"teal",
		"orange",
		"lavender",
		"blue",
		"rose"
	]),
	archived: booleanType(),
	demo: booleanType(),
	createdAt: stringType().datetime(),
	notes: stringType().max(1e4),
	bookPages: numberType().int().min(0).max(1e5).default(0),
	bookFileName: stringType().max(255).default(""),
	outlineSource: enumType([
		"manual",
		"pdf-bookmarks",
		"pdf-pages",
		"epub-toc",
		"ai-plan"
	]).default("manual"),
	folderPath: stringType().max(200).default(""),
	focusModule: stringType().max(200).default(""),
	captureScope: enumType([
		"manual",
		"page",
		"folder",
		"course"
	]).default("manual"),
	captureNote: stringType().max(1200).default(""),
	lessons: arrayType(lessonSchema).min(1).max(500)
});
var inboxSchema = objectType({
	id: stringType().min(1).max(100),
	workspace: workspaceSchema,
	text: stringType().trim().min(1).max(1e4),
	createdAt: stringType().datetime(),
	status: enumType(["inbox", "filed"]).default("inbox"),
	source: enumType(["typed", "shared"]).default("typed")
});
var stateSchema = objectType({
	version: literalType(1),
	screenTime: arrayType(screenSummarySchema).max(180).refine((a) => new Set(a.map((s) => s.id)).size === a.length, "Duplicate screen-time IDs").default([]),
	inbox: arrayType(inboxSchema).max(300).default([]),
	todos: arrayType(todoSchema).max(200).default([]),
	rewards: arrayType(rewardSchema).max(30).default([]),
	activityRemovals: arrayType(objectType({
		id: stringType().min(1).max(210),
		kind: enumType([
			"resource",
			"lesson",
			"log",
			"session"
		]),
		targetId: stringType().min(1).max(100),
		at: stringType().datetime(),
		lessonId: stringType().max(100).default("")
	})).max(2e4).default([]),
	coach: coachStateSchema,
	studyLog: arrayType(objectType({
		id: stringType().min(1).max(100),
		resourceId: stringType().max(100),
		lessonId: stringType().max(100),
		minutes: numberType().int().min(1).max(600),
		at: stringType().datetime()
	})).max(2e4).default([]),
	resources: arrayType(resourceSchema).max(300),
	goals: arrayType(objectType({
		workspace: workspaceSchema,
		id: stringType().min(1).max(100),
		title: stringType().min(1).max(120),
		description: stringType().max(500),
		image: goalImageSchema,
		importance: numberType().int().min(1).max(5)
	})).max(30),
	settings: objectType({
		workDailyMinutes: numberType().int().min(10).max(480).default(30),
		workFocusGoal: stringType().max(100).default(""),
		theme: enumType([
			"light",
			"dark",
			"system"
		]).default("system"),
		dailyMinutes: numberType().int().min(10).max(480),
		weeklyDays: numberType().int().min(1).max(7),
		timezone: stringType().refine((s) => {
			try {
				new Intl.DateTimeFormat("en", { timeZone: s });
				return true;
			} catch {
				return false;
			}
		}),
		focusGoal: stringType().max(100),
		streakMinimum: numberType().int().min(1).max(60).default(5)
	})
}).superRefine((s, ctx) => {
	for (const r of s.resources) for (const l of r.lessons) if (l.studiedMinutes > l.minutes) ctx.addIssue({
		code: ZodIssueCode.custom,
		message: "Studied time exceeds lesson duration"
	});
	const ids = s.resources.map((r) => r.id), lessons = s.resources.flatMap((r) => r.lessons.map((l) => l.id)), goals = s.goals.map((g) => g.id), conversations = s.coach.conversations.map((c) => c.id), messages = s.coach.conversations.flatMap((c) => c.messages.map((m) => m.id)), sessions = s.coach.sessions.map((s) => s.id);
	for (const items of [
		s.todos,
		s.rewards,
		s.inbox
	]) if (new Set(items.map((x) => x.id)).size !== items.length) ctx.addIssue({
		code: ZodIssueCode.custom,
		message: "Duplicate task or reward IDs"
	});
	const logIds = s.studyLog.map((l) => l.id), removalIds = s.activityRemovals.map((e) => e.id);
	if (new Set(logIds).size !== logIds.length || new Set(removalIds).size !== removalIds.length || s.activityRemovals.some((e) => e.id !== e.kind + ":" + e.targetId)) ctx.addIssue({
		code: ZodIssueCode.custom,
		message: "Invalid or duplicate activity IDs"
	});
	if (new Set(sessions).size !== sessions.length || new Set(ids).size !== ids.length || new Set(lessons).size !== lessons.length || new Set(goals).size !== goals.length || new Set(conversations).size !== conversations.length || new Set(messages).size !== messages.length) ctx.addIssue({
		code: ZodIssueCode.custom,
		message: "Duplicate IDs in import"
	});
});
var parseLibrary = (raw) => normalizeActivity(stateSchema.parse(raw));
function preserveSourceMetadata(raw, parsed, previous) {
	if (raw.screenTime === void 0) parsed.screenTime = previous.screenTime;
	else for (const row of parsed.screenTime) {
		const input = raw.screenTime.find((x) => x.id === row.id), old = previous.screenTime.find((x) => x.id === row.id);
		if (!input || !old || input.capturedAt !== old.capturedAt) continue;
		if (input.measurement === void 0) row.measurement = old.measurement;
		if (input.topApps === void 0) row.topApps = old.topApps;
	}
	for (const key of [
		"tone",
		"useScreenTime",
		"contextVersion",
		"contextMode",
		"dailyEnabled",
		"dailyReviews"
	]) if (raw.coach?.[key] === void 0) parsed.coach[key] = previous.coach[key];
	for (const row of parsed.coach.dailyReviews) {
		const input = raw.coach?.dailyReviews?.find((x) => x.id === row.id), old = previous.coach.dailyReviews.find((x) => x.id === row.id);
		if (input && old && input.at === old.at && input.requestVersion === void 0) row.requestVersion = old.requestVersion;
	}
	if (raw.coach?.memories === void 0) parsed.coach.memories = previous.coach.memories;
	for (const c of parsed.coach.conversations) if (raw.coach?.conversations.find((x) => x.id === c.id)?.contextSelection === void 0) c.contextSelection = previous.coach.conversations.find((x) => x.id === c.id)?.contextSelection;
	for (const c of parsed.coach.conversations) for (const m of c.messages) {
		const input = raw.coach?.conversations.find((x) => x.id === c.id)?.messages.find((x) => x.id === m.id), old = previous.coach.conversations.find((x) => x.id === c.id)?.messages.find((x) => x.id === m.id);
		if (!input || !old) continue;
		for (const key of [
			"actionReceipt",
			"actionGuard",
			"actionScope"
		]) if (input[key] === void 0 && old[key] !== void 0) m[key] = old[key];
		if (input.reply && input.reply.actions === void 0 && old.reply?.actions && m.reply) m.reply.actions = old.reply.actions;
		if (old.appliedAt && input.actionReceipt === void 0) m.appliedAt = old.appliedAt;
	}
	if (raw.inbox === void 0) parsed.inbox = previous.inbox;
	if (raw.settings.workDailyMinutes === void 0) parsed.settings.workDailyMinutes = previous.settings.workDailyMinutes;
	if (raw.settings.workFocusGoal === void 0) parsed.settings.workFocusGoal = previous.settings.workFocusGoal;
	for (const key of [
		"goals",
		"todos",
		"rewards"
	]) for (const item of parsed[key]) {
		const input = raw[key]?.find((x) => x.id === item.id);
		if (input && input.workspace === void 0) item.workspace = previous[key].find((x) => x.id === item.id)?.workspace || "personal";
	}
	if (raw.todos === void 0) parsed.todos = previous.todos;
	if (raw.rewards === void 0) parsed.rewards = previous.rewards;
	for (const g of parsed.goals) if (raw.goals.find((x) => x.id === g.id)?.image === void 0) g.image = previous.goals.find((x) => x.id === g.id)?.image || "";
	for (const r of parsed.resources) {
		const old = previous.resources.find((x) => x.id === r.id), input = raw.resources.find((x) => x.id === r.id);
		if (!old || !input) continue;
		if (input.thumbnailUrl === void 0) r.thumbnailUrl = old.thumbnailUrl;
		if (input.excerpt === void 0) r.excerpt = old.excerpt;
		for (const key of [
			"coverImage",
			"workspace",
			"quickLog"
		]) if (input[key] === void 0) r[key] = old[key];
		for (const l of r.lessons) {
			const oldLesson = old.lessons.find((x) => x.id === l.id), inputLesson = input.lessons.find((x) => x.id === l.id);
			if (!oldLesson || !inputLesson) continue;
			for (const key of [
				"thumbnailUrl",
				"durationSeconds",
				"durationEstimated"
			]) if (inputLesson[key] === void 0) l[key] = oldLesson[key];
		}
	}
}
function seedState() {
	const date = (/* @__PURE__ */ new Date()).toISOString();
	const build = (id, title, provider, kind, color, goalId, priority, titles, minutes, done = 0, url = "") => ({
		id,
		title,
		provider,
		kind,
		color,
		goalId,
		priority,
		url,
		deadline: "",
		archived: false,
		demo: true,
		createdAt: date,
		notes: "",
		lessons: titles.map((title, i) => ({
			id: id + "-" + i,
			title,
			minutes: minutes[i] || 15,
			url,
			done: i < done,
			completedAt: null,
			notes: "",
			pinned: false
		}))
	});
	return stateSchema.parse({
		version: 1,
		settings: {
			dailyMinutes: 45,
			weeklyDays: 5,
			timezone: "Asia/Kolkata",
			focusGoal: "build"
		},
		goals: [
			{
				id: "build",
				title: "Build better products",
				description: "Turn ideas into thoughtful, useful software.",
				importance: 5
			},
			{
				id: "ai",
				title: "Get fluent with AI",
				description: "Understand models and build practical AI tools.",
				importance: 4
			},
			{
				id: "design",
				title: "Think like a designer",
				description: "Learn the principles behind great interfaces.",
				importance: 3
			}
		],
		resources: [
			build("react", "The Complete React Course", "Udemy", "course", "teal", "build", 5, [
				"Welcome & setup",
				"Thinking in components",
				"Your first component",
				"Props & composition",
				"Rendering lists",
				"State and events",
				"Understanding useEffect",
				"Managing complex state",
				"Building a custom hook",
				"Working with context",
				"Shipping your first app"
			], [
				8,
				12,
				15,
				20,
				10,
				15,
				18,
				22,
				15,
				18,
				30
			], 6, "https://www.udemy.com/"),
			build("ai-course", "AI Engineering, from the ground up", "YouTube", "course", "lavender", "ai", 4, [
				"A map of the AI landscape",
				"How language models work",
				"Embeddings, visually explained",
				"Retrieval augmented generation",
				"Build a simple AI assistant"
			], [
				12,
				18,
				15,
				22,
				30
			], 2, "https://www.youtube.com/"),
			build("design-course", "Design for Developers", "Independent course", "course", "orange", "design", 4, [
				"Start with a clear hierarchy",
				"Spacing is a design tool",
				"Typography that works",
				"Color with intention",
				"Bring it all together"
			], [
				10,
				12,
				18,
				15,
				25
			], 1),
			build("article", "A practical guide to better habits", "Article", "article", "blue", "build", 3, ["Read & capture one idea"], [12], 0),
			build("systems", "System design fundamentals", "YouTube", "video", "blue", "build", 3, ["Scalability & tradeoffs"], [25], 0, "https://www.youtube.com/"),
			build("writing", "Writing that makes things clear", "Topic", "topic", "rose", "", 2, ["Write a short explanation of something you learned"], [20], 0),
			build("typescript", "TypeScript Essentials", "YouTube", "course", "teal", "build", 3, [
				"Types & interfaces",
				"Generics in practice",
				"Narrowing & inference",
				"Make a reusable utility"
			], [
				15,
				18,
				20,
				15
			], 0, "https://www.youtube.com/"),
			build("css", "A deeper look at CSS Grid", "Article", "article", "orange", "design", 2, ["Read & try a layout"], [15], 0)
		]
	});
}
//#endregion
//#region lib/focus-balance.ts
var balanceSettingsSchema = objectType({
	enabled: booleanType().default(false),
	budgetMinutes: numberType().int().min(5).max(480).default(60),
	deviceId: stringType().max(100).default(""),
	syncSummaries: booleanType().default(false),
	shareAppNames: booleanType().default(false),
	categories: recordType(enumType([
		"learning",
		"leisure",
		"neutral",
		"mixed"
	])).default({})
});
var usageReportSchema = objectType({
	granted: booleanType(),
	timezone: stringType().max(100).default(""),
	capturedAt: stringType().datetime(),
	platform: enumType(["android", "mac"]).default("android"),
	paused: booleanType().default(false),
	trackedSince: stringType().datetime().optional(),
	days: arrayType(objectType({
		day: stringType().regex(/^\d{4}-\d{2}-\d{2}$/),
		minutes: numberType().min(0).max(1500),
		available: booleanType().optional(),
		measurement: usageMeasurementSchema.optional(),
		apps: arrayType(objectType({
			id: stringType().max(250),
			name: stringType().max(250),
			minutes: numberType().min(0).max(1500)
		})).max(300)
	})).max(7)
});
//#endregion
//#region lib/screen-time.ts
function usageSummaries(report, settings, deviceId, deviceName = "Phone") {
	if (!settings.enabled || !settings.syncSummaries || !report.granted || !deviceId) return [];
	return report.days.filter((d) => d.available ?? d.apps.length > 0).map((d) => screenSummarySchema.parse({
		id: deviceId + ":" + d.day,
		deviceId,
		deviceName,
		platform: report.platform,
		day: d.day,
		timezone: report.timezone,
		capturedAt: report.capturedAt,
		totalMinutes: d.minutes,
		neutralMinutes: d.minutes,
		budgetMinutes: settings.budgetMinutes,
		partial: true,
		measurement: d.measurement || { method: report.platform === "mac" ? "mac-foreground-v1" : "legacy" },
		topApps: settings.shareAppNames ? [...d.apps].sort((a, b) => b.minutes - a.minutes).slice(0, 5).map((a) => ({
			name: a.name.slice(0, 120),
			minutes: a.minutes
		})) : []
	}));
}
function mergeScreenSummaries(existing, incoming) {
	const map = new Map(existing.map((s) => [s.id, s]));
	for (const row of incoming) {
		const old = map.get(row.id);
		if (!old || row.capturedAt >= old.capturedAt) map.set(row.id, row);
	}
	return [...map.values()].sort((a, b) => b.day.localeCompare(a.day) || a.id.localeCompare(b.id)).slice(0, 180);
}
function updateScreenSummaries(state, incoming) {
	const screenTime = mergeScreenSummaries(state.screenTime, incoming);
	return JSON.stringify(screenTime) === JSON.stringify(state.screenTime) ? state : {
		...state,
		screenTime
	};
}
//#endregion
//#region lib/mac-screen-time.ts
var macUsageDirectory = () => join(homedir(), "Library", "Application Support", "Learning Space");
function macScreenPacket(directory = macUsageDirectory()) {
	const configFile = join(directory, "settings.json"), reportFile = join(directory, "usage.json");
	let settings = balanceSettingsSchema.parse({}), report = null;
	if (existsSync(configFile)) settings = balanceSettingsSchema.parse(JSON.parse(readFileSync(configFile, "utf8")));
	if (existsSync(reportFile)) report = usageReportSchema.parse(JSON.parse(readFileSync(reportFile, "utf8")));
	return {
		settings,
		report
	};
}
function saveMacScreenSettings(raw, directory = macUsageDirectory()) {
	let settings = balanceSettingsSchema.parse(raw);
	if (!settings.deviceId) {
		let previous = "";
		try {
			previous = macScreenPacket(directory).settings.deviceId;
		} catch {}
		settings = {
			...settings,
			deviceId: previous || randomUUID()
		};
	}
	mkdirSync(directory, {
		recursive: true,
		mode: 448
	});
	const file = join(directory, "settings.json");
	writeFileSync(file + ".tmp", JSON.stringify(settings), { mode: 384 });
	renameSync(file + ".tmp", file);
	return settings;
}
function ingestMacScreenTime(state, directory = macUsageDirectory()) {
	try {
		const packet = macScreenPacket(directory);
		if (!packet.report) return state;
		return updateScreenSummaries(state, usageSummaries(packet.report, packet.settings, packet.settings.deviceId, "Mac"));
	} catch {
		return state;
	}
}
//#endregion
//#region scripts/lan-server.ts
var own = fileURLToPath(new URL(".", import.meta.url));
var project = existsSync(join(own, "www")) ? own : resolve(own, "..");
function startLanServer(options = {}) {
	const dir = options.dataDir || join(project, ".local-learning"), webRoot = options.webRoot || join(project, existsSync(join(project, "www")) ? "www" : ".offline-dist"), downloads = options.downloadRoot || join(project, existsSync(join(project, "www/downloads")) ? "www/downloads" : "public/downloads");
	mkdirSync(dir, {
		recursive: true,
		mode: 448
	});
	const codeFile = join(dir, "connection-code");
	let code = options.code || (existsSync(codeFile) ? readFileSync(codeFile, "utf8").trim() : randomBytes(32).toString("base64url"));
	if (!existsSync(codeFile)) writeFileSync(codeFile, code, { mode: 384 });
	chmodSync(codeFile, 384);
	const stateFile = join(dir, "library.json");
	const read = () => {
		if (!existsSync(stateFile)) return {
			revision: 0,
			state: seedState()
		};
		const packet = JSON.parse(readFileSync(stateFile, "utf8"));
		return {
			revision: packet.revision,
			state: parseLibrary(packet.state)
		};
	};
	const write = (packet) => {
		writeFileSync(stateFile + ".tmp", JSON.stringify(packet), { mode: 384 });
		renameSync(stateFile + ".tmp", stateFile);
	};
	const privateIP = (ip) => {
		ip = ip.replace(/^::ffff:/, "");
		return ip === "::1" || ip.startsWith("127.") || /^10\./.test(ip) || /^192\.168\./.test(ip) || /^172\.(1[6-9]|2\d|3[01])\./.test(ip);
	};
	const json = (res, value, status = 200) => {
		res.writeHead(status, {
			"Content-Type": "application/json",
			"Cache-Control": "no-store",
			"X-Content-Type-Options": "nosniff"
		});
		res.end(JSON.stringify(value));
	};
	const server = createServer(async (req, res) => {
		try {
			const remote = req.socket.remoteAddress || "";
			if (!privateIP(remote)) return json(res, { error: "Local network connections only." }, 403);
			const host = (req.headers.host || "").split(":")[0];
			const ips = Object.values(networkInterfaces()).flat().filter((x) => x?.family === "IPv4").map((x) => x.address);
			if (![
				"localhost",
				"127.0.0.1",
				...ips
			].includes(host)) return json(res, { error: "Invalid host." }, 403);
			const origin = req.headers.origin;
			if (origin) {
				const u = new URL(origin);
				if (!privateIP(u.hostname) && u.hostname !== "localhost") return json(res, { error: "Invalid origin." }, 403);
				res.setHeader("Access-Control-Allow-Origin", origin);
				res.setHeader("Vary", "Origin");
				res.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
				res.setHeader("Access-Control-Allow-Methods", "GET,PUT,OPTIONS");
			}
			if (req.method === "OPTIONS") {
				res.writeHead(204);
				return res.end();
			}
			const url = new URL(req.url || "/", "http://" + req.headers.host), path = url.pathname;
			if (path === "/api/screen-time") {
				if (![
					"127.0.0.1",
					"::1",
					"::ffff:127.0.0.1"
				].includes(remote) || origin && new URL(origin).origin !== url.origin) return json(res, { error: "Open screen time on this computer." }, 403);
				if (req.method === "GET") try {
					return json(res, macScreenPacket(options.macUsageDir));
				} catch {
					return json(res, { error: "Mac usage file could not be read." }, 400);
				}
				if (req.method !== "PUT" || !origin || new URL(origin).origin !== url.origin) return json(res, { error: "Invalid request." }, 403);
				let raw = "";
				for await (const chunk of req) {
					raw += chunk.toString();
					if (Buffer.byteLength(raw) > 15e4) return json(res, { error: "Settings too large." }, 413);
				}
				try {
					return json(res, { settings: saveMacScreenSettings(JSON.parse(raw).settings, options.macUsageDir) });
				} catch {
					return json(res, { error: "Invalid screen-time settings." }, 400);
				}
			}
			if (path === "/api/import") {
				if (req.method !== "POST") return json(res, { error: "Method not allowed." }, 405);
				if (!origin || new URL(origin).origin !== url.origin) return json(res, { error: "Open imports on this computer’s learning dashboard." }, 403);
				let raw = "";
				for await (const chunk of req) {
					raw += chunk.toString();
					if (Buffer.byteLength(raw) > 4e3) return json(res, { error: "Link is too long." }, 413);
				}
				try {
					const input = JSON.parse(raw);
					if (typeof input.url !== "string" || input.url.length > 2e3 || !youtubeLink(input.url)) return json(res, { error: "Use a YouTube playlist or video link." }, 400);
					return json(res, await importYouTube(input.url));
				} catch (e) {
					return json(res, { error: e.message || "YouTube could not be reached." }, 502);
				}
			}
			if (path === "/lan/setup") {
				if (origin && new URL(origin).origin !== url.origin) return json(res, { error: "Open connection setup on this computer." }, 403);
				if (![
					"127.0.0.1",
					"::1",
					"::ffff:127.0.0.1"
				].includes(remote)) return json(res, { error: "Open Settings on the computer to get its connection code." }, 403);
				const port = server.address().port;
				return json(res, {
					code,
					addresses: ips.filter((ip) => privateIP(ip) && !ip.startsWith("127.")).map((ip) => "http://" + ip + ":" + port)
				});
			}
			if (path.startsWith("/lan/")) {
				const supplied = (req.headers.authorization || "").replace(/^Bearer /, "");
				const a = Buffer.from(supplied), b = Buffer.from(code);
				if (a.length !== b.length || !timingSafeEqual(a, b)) return json(res, { error: "Connection code required." }, 401);
				if (path !== "/lan/state") return json(res, { error: "Not found." }, 404);
				if (req.method === "GET") {
					const packet = read();
					const next = ingestMacScreenTime(packet.state, options.macUsageDir);
					if (next !== packet.state) {
						packet.state = next;
						packet.revision++;
						write(packet);
					}
					return json(res, packet);
				}
				if (req.method !== "PUT") return json(res, { error: "Method not allowed." }, 405);
				let raw = "";
				for await (const chunk of req) {
					raw += chunk.toString();
					if (Buffer.byteLength(raw) > 4e6) {
						json(res, { error: "Library exceeds 4 MB." }, 413);
						req.destroy();
						return;
					}
				}
				let data;
				try {
					data = JSON.parse(raw);
				} catch {
					return json(res, { error: "Invalid JSON." }, 400);
				}
				const parsed = stateSchema.safeParse(data.state);
				if (!parsed.success || !Number.isInteger(data.revision) || data.revision < 0) return json(res, { error: "Invalid library." }, 400);
				const old = read();
				if (old.revision !== data.revision) return json(res, { error: "The computer library changed. Sync again." }, 409);
				preserveSourceMetadata(data.state, parsed.data, old.state);
				if (data.state.activityRemovals === void 0) parsed.data.activityRemovals = old.state.activityRemovals;
				if (data.state.coach === void 0) parsed.data.coach = old.state.coach;
				else {
					if (data.state.coach.sessions === void 0) parsed.data.coach.sessions = old.state.coach.sessions;
					if (data.state.coach.autoReviews === void 0) parsed.data.coach.autoReviews = old.state.coach.autoReviews;
				}
				if (data.state.settings.theme === void 0) parsed.data.settings.theme = old.state.settings.theme;
				const packet = {
					state: parseLibrary(parsed.data),
					revision: old.revision + 1
				};
				write(packet);
				return json(res, { revision: packet.revision });
			}
			if (req.method !== "GET" && req.method !== "HEAD") return json(res, { error: "Method not allowed." }, 405);
			const root = path.startsWith("/downloads/") ? downloads : webRoot;
			let relative = path.startsWith("/downloads/") ? path.slice(11) : path.replace(/^\//, "");
			if (!relative) relative = "index.html";
			const file = resolve(root, decodeURIComponent(relative));
			if (!file.startsWith(resolve(root) + "/") || !existsSync(file) || !statSync(file).isFile()) return json(res, { error: "Not found." }, 404);
			res.writeHead(200, {
				"Content-Type": {
					".html": "text/html",
					".js": "text/javascript",
					".mjs": "text/javascript",
					".css": "text/css",
					".svg": "image/svg+xml",
					".json": "application/json",
					".apk": "application/vnd.android.package-archive",
					".zip": "application/zip"
				}[extname(file)] || "application/octet-stream",
				"Cache-Control": "no-cache",
				"X-Content-Type-Options": "nosniff"
			});
			res.end(req.method === "HEAD" ? void 0 : readFileSync(file));
		} catch {
			if (!res.headersSent) json(res, { error: "Could not process the request. The saved library is unchanged." }, 500);
			else res.end();
		}
	});
	server.listen(options.port ?? 5180, options.host || "0.0.0.0");
	return server;
}
if (process.argv[1] && existsSync(process.argv[1]) && import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href) {
	const server = startLanServer({ port: Number(process.env.LEARNING_LAN_PORT || 5180) });
	server.on("listening", () => console.log("Learning Space Wi-Fi server: http://localhost:" + server.address().port + " · Open Settings to pair your phone."));
	server.on("error", (e) => {
		console.error("Could not start Wi-Fi server:", e.message);
		process.exitCode = 1;
	});
}
//#endregion
export { startLanServer };
