# Learning Space on your Wi-Fi

Requirements: Node.js 22.13 or newer. No account or npm install is needed for the standalone download.

1. Unzip the computer setup into a folder you intend to keep.
2. In that folder, run `node server.mjs`.
3. Open `http://localhost:5180/` on this computer. The library works without login.
4. Open Settings → On this device. Copy the Wi-Fi address and connection code to the phone app’s Wi-Fi settings. Choose Save connection & sync on the phone.

Leave the server running when you want to sync. Without it, the phone continues using its own library. The connection code is persistent, not an expiring sign-in link. If the computer’s Wi-Fi IP changes, update the phone address. Guest Wi-Fi isolation or a firewall can block the connection.

Data and the code live in `.local-learning/` beside this setup. Keep that folder across restarts; it is not included in downloads. Back up the library through dashboard Settings. Existing hosted data can be exported once and restored here/on the phone. Original PDF/EPUB files and OpenAI keys are not transferred by sync.

Sync combines independent changes and asks which value to keep when both devices edit the same field. It does not silently replace a whole library. Wi-Fi traffic uses HTTP and a saved connection code; use this on your own trusted private network. Internet/public IPs are rejected for native app connections, and the library endpoints require the code. This server is not an internet deployment.

From the source project, use `npm run build:offline` followed by `npm run lan` instead. The standalone build already contains all browser assets and the Android APK at `/downloads/learning-space-android.apk`.


Version 0.12: update the computer setup together with the Android app. This release adds Personal/Work spaces, a capture inbox, resource covers, quick logs and daily progress cards while preserving earlier learning history. The app pauses sync with older computer servers to protect those fields. Keep the existing `.local-learning` folder when replacing server and www files; it contains your library and connection code.


## Automatic screen-time summaries (0.14)

Update both the Android app and computer setup to 0.16. Keep the existing `.local-learning` folder. In the phone’s Progress → Screen time → settings, enable phone usage and Android Usage access, turn on automatic daily summary sync. Usage refreshes on open/resume and every two minutes while the app is visible. Existing Wi-Fi auto-sync runs while the app is open; this is not a background Android monitoring service. The phone works locally without Wi-Fi.

For Mac foreground time, download `learning-space-mac-time.zip` from Progress → Screen time. It requires macOS 15 or newer and supports Apple Silicon and Intel. Unzip, open Learning Space Time, and choose Start tracking. The menu-bar companion records foreground app names and time only while running, and pauses during sleep or after one minute of inactivity. This is a new recording, not an import of Apple’s Screen Time history. It is ad-hoc signed, not Apple-notarized; review macOS’s security prompt before choosing to open it.

Open this computer’s local dashboard at `http://localhost:5180/`. In Screen-time settings, set a screen-time budget and optionally enable summary sync. The server reads the companion’s local file during normal phone sync even when the computer’s browser is closed. Keep the companion and this server running. Raw app records and preferences stay in `~/Library/Application Support/Learning Space/` with private file permissions. The optional shared summaries contain total device time and measurement details; app names require a separate choice. Device-minutes may overlap.

“Let coach use synced screen time” is another explicit switch. It adds the available summaries to chats and session reviews using your existing key. Refresh and sync never trigger an AI call by themselves. The hosted website remains a separate library and can receive summaries through an exported backup.


## Daily coach records (0.15)

Update this server alongside Android 0.15, preserving `.local-learning/`. Daily reviews and context preferences travel with normal Wi-Fi sync. Android owns the background schedule and key; the computer does not need to stay awake for a phone review. The hosted website still has its separate account library. This server does not install a cloud schedule or automatically receive an API key.

## Total screen time (0.16)

All phone and Mac use counts against each device’s chosen screen-time budget; no categories are required. Phone totals use observed unlocked-screen intervals when available, and otherwise a labelled app activity estimate. Mac totals remain foreground app estimates. Keep the existing data folder when replacing this setup. Older backup totals are still readable; newly synced summaries preserve measurement details.

## Quick logging (0.17)

The dashboard accepts links with or without `https://` in quick logs, displays field errors, and waits for the local library write to complete. Replace the computer setup files while retaining the existing data folder.

## Midnight review dates (0.18)

Replace the server files while retaining the data folder to preserve review request-version metadata during Wi-Fi sync. The phone remains responsible for background generation. A review generated after midnight normally covers the preceding local date. Older request-format reviews can be regenerated from the phone using its existing key.
